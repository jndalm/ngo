#include "form_dash.h"
#include "ui_form_dash.h"
#include<QProgressBar>
#include<QRoundProgressBar.h>

form_dash::form_dash(QString id) :
    ui(new Ui::form_dash)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);

    dbsclass dbs;
    ui->lbl_emp_id->setText(id);
    dbs.fill_label(ui->lbl_emp_name,"SELECT name FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);





    QString q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan";
    dbs.tv_display(ui->tv_busnessStatus,q2);
    ui->tv_busnessStatus->resizeColumnsToContents();

    ui->tbx_loan_amount->setText(QString::number(dbs.fill_array(q2,7),'g',12));
    ui->tbx_ret_amo->setText(QString::number(dbs.fill_array(q2,9),'g',12));
    ui->tbx_col_amo->setText(QString::number(dbs.fill_array(q2,11),'g',12));
    ui->tbx_col_capital->setText(QString::number(dbs.fill_array(q2,14),'g',12));
    ui->tbx_totlbene->setText(QString::number(dbs.fill_array(q2,10),'g',12));
    ui->tbx_col_bene->setText(QString::number(dbs.fill_array(q2,13),'g',12));

    ui->tbx_due_amo->setText(QString::number(ui->tbx_ret_amo->text().toDouble()-ui->tbx_col_amo->text().toDouble()));
    ui->tbx_due_capital->setText(QString::number(ui->tbx_loan_amount->text().toDouble()-ui->tbx_col_capital->text().toDouble()));
    ui->tbx_due_bene->setText(QString::number(ui->tbx_totlbene->text().toDouble()-ui->tbx_col_bene->text().toDouble()));


    for(int i=0;i<dbs.tbl_sz(q2);i++){
        QProgressBar *prog=new QProgressBar();

        QModelIndex in=ui->tv_busnessStatus->model()->index(i,15,QModelIndex());
        QString val=ui->tv_busnessStatus->model()->data(in).toString();
        QModelIndex in2=ui->tv_busnessStatus->model()->index(i,2,QModelIndex());
        prog->setValue(val.toDouble());
        prog->setTextVisible(true);
        ui->tv_busnessStatus->setIndexWidget(in2,prog);
    }


    QString q_pie="select day as Day,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by day order by sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) desc";
    double ttl=dbs.fill_array(q_pie,2),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q_pie,2);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q_pie);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString namee=dbs.fill_array_string(q_pie,0),nam="",bbb;
    QStringList n=namee.split(",");
    for(int i=0;i<dbs.tbl_sz(q_pie);i++){
        bbb=n.value(i);

        if(i==0){

            nam+=bbb;
        }
        else{
            nam+=",";
            nam+=bbb;
        }
    }
    dbs.pie3d(ui->lbl_pie_day,nam,val);
    dbs.bargraph3d(ui->lbl_bar_chart_,nam,val);



    ui->rnd_coll_progress->setValue((100/(ui->tbx_ret_amo->text().toDouble()/ui->tbx_col_amo->text().toDouble())));

    QString temp=ui->ctbx_loan_notif->currentText();
    ui->ctbx_loan_notif->setEditText("");
    ui->ctbx_loan_notif->setEditText(temp);

}

form_dash::~form_dash()
{
    delete ui;
}

void form_dash::on_btn_loan_clicked()
{
    form_loan *m=new form_loan(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}


void form_dash::on_btn_member_clicked()
{
    form_agent *m=new form_agent(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_dash::on_btn_collection_clicked()
{
    form_daily_collection *m=new form_daily_collection(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_dash::on_btn_cancel_clicked()
{
    login *w=new login;
    w->show();
    this->hide();
}

void form_dash::on_btn_visualization_clicked()
{
    form_visualization *m=new form_visualization(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_dash::on_btn_dash_loan_pie_clicked()
{
    dbsclass dbs;
    QString q_pie="select day as Day,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by day order by sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) desc";
    double ttl=dbs.fill_array(q_pie,2),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q_pie,2);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q_pie);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString namee=dbs.fill_array_string(q_pie,0),nam="",bbb;
    QStringList n=namee.split(",");
    for(int i=0;i<dbs.tbl_sz(q_pie);i++){
        bbb=n.value(i);

        if(i==0){

            nam+=bbb;
        }
        else{
            nam+=",";
            nam+=bbb;
        }
    }
    dbs.pie3d(ui->lbl_pie_day,nam,val);
    //dbs.bargraph3d(ui->lbl_bar_chart_,nam,val);


}


void form_dash::on_btn_dash_loan_bar_clicked()
{
    dbsclass dbs;
    QString q_pie="select day as Day,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by day order by sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) desc";
    double ttl=dbs.fill_array(q_pie,2),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q_pie,2);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q_pie);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString namee=dbs.fill_array_string(q_pie,0),nam="",bbb;
    QStringList n=namee.split(",");
    for(int i=0;i<dbs.tbl_sz(q_pie);i++){
        bbb=n.value(i);

        if(i==0){

            nam+=bbb;
        }
        else{
            nam+=",";
            nam+=bbb;
        }
    }
    dbs.bargraph3d(ui->lbl_pie_day,nam,val);
    //dbs.bargraph3d(ui->lbl_bar_chart_,nam,val);
}

void form_dash::on_ctbx_loan_notif_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q,sd,ed;
    QDate e_dat=QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"),s_dat;
    ed=e_dat.toString("yyyy-MM-dd");
    if(arg1=="Todays Collection"){
        q="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT Phone FROM ngo.member where id=loan.member) as Phone_Number, DATE_FORMAT(now(), '%Y-%m-%d') as Today,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed FROM ngo.loan where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)%gap+0=0";
        //QString q1="SELECT DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),STR_TO_DATE(opening_date, '%d/%m/%y')) as ddd  FROM ngo.loan ";

    }
    else if(arg1=="Empty Collection(Last 3 Months)"){
        //QString::
        s_dat=e_dat.addDays(-90);
        ui->tbx_start_date_inv->setDate(s_dat);
        sd=s_dat.toString("yyyy-MM-dd");
        ui->tbx_search_dash_notif->setText(sd);
        q="select loan as Loan_Id,(SELECT Name FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Name,(SELECT Phone FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Phone_Number,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null and date(DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') order by loan";

    }
    else if(arg1=="Empty Collection(Last 6 Months)"){
        //QString::
        s_dat=e_dat.addDays(-180);
        ui->tbx_start_date_inv->setDate(s_dat);
        sd=s_dat.toString("yyyy-MM-dd");
        ui->tbx_search_dash_notif->setText(sd);
        q="select loan as Loan_Id,(SELECT Name FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Name,(SELECT Phone FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Phone_Number,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null and date(DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') order by loan";

    }
    else if(arg1=="Empty Collection(This Month)"){
        //QString::
        s_dat=e_dat.addDays(-30);
        ui->tbx_start_date_inv->setDate(s_dat);
        sd=s_dat.toString("yyyy-MM-dd");
        ui->tbx_search_dash_notif->setText(sd);
        q="select loan as Loan_Id,(SELECT Name FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Name,(SELECT Phone FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Phone_Number,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null and date(DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') order by loan";

    }
    else if(arg1=="Empty Collection(This Week)"){
        //QString::
        s_dat=e_dat.addDays(-7);
        ui->tbx_start_date_inv->setDate(s_dat);
        sd=s_dat.toString("yyyy-MM-dd");
        ui->tbx_search_dash_notif->setText(sd);
        q="select loan as Loan_Id,(SELECT Name FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Name,(SELECT Phone FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Phone_Number,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null and date(DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') order by loan";

    }
    else if(arg1=="Empty Collection(This Year)"){
        //QString::
        s_dat=e_dat.addDays(-365);
        ui->tbx_start_date_inv->setDate(s_dat);
        sd=s_dat.toString("yyyy-MM-dd");
        ui->tbx_search_dash_notif->setText(sd);
        q="select loan as Loan_Id,(SELECT Name FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Name,(SELECT Phone FROM ngo.member where id=(SELECT member FROM ngo.loan where id=collection.loan)) as Phone_Number,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null and date(DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') order by loan";

    }
    else{
        q="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT Phone FROM ngo.member where id=loan.member) as Phone_Number, DATE_FORMAT(now(), '%Y-%m-%d') as Today,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed FROM ngo.loan where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)%gap+0=0";
        //QString q1="SELECT DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),STR_TO_DATE(opening_date, '%d/%m/%y')) as ddd  FROM ngo.loan ";

    }





    dbs.tv_display(ui->tv_todays_collection,q);
    ui->tv_todays_collection->resizeColumnsToContents();
}

void form_dash::on_btn_deposit_clicked()
{
    form_diposit *m=new form_diposit(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_dash::on_btn_payment_clicked()
{
    form_daily_payment *m=new form_daily_payment(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_dash::on_btn_export_clicked()
{
    dbsclass dbs;

    QString q;
    QString q_tbl_list="collection,employee,loan,member,diposit,payment";
    QStringList lst_tbl=q_tbl_list.split(",");
    //dbs.tv_display(ui->tv_csv_table,q_tbl_list);

    for(int i=0;i<lst_tbl.size();i++){
        q="select * from ngo."+lst_tbl.value(i)+"";
        dbs.tv_display(ui->tv_csv_table,q);
        dbs.csv_exp(ui->tv_csv_table,ui->tbx_tech->text()+lst_tbl.value(i));
        ui->progressBar->setValue((i*100)/lst_tbl.size());
    }
    ui->progressBar->setValue(100);
}


void form_dash::on_btn_import_clicked()
{
    dbsclass dbs;
    int sz;
    QString q_tbl_list="collection,employee,loan,member,diposit,payment",q;
    QStringList lst_tbl=q_tbl_list.split(",");
    QString q_insert_statement;
    QModelIndex ind;
    for(int j=0;j<lst_tbl.size();j++){
        //_________________________________________________________________________________________

        QString filePath,full,temp;
        QStringList header_value;
        QStringList full_lst;
        QStandardItemModel *mod = new QStandardItemModel;

        filePath=ui->tbx_tech->text()+lst_tbl.value(j)+".csv";
        //ui->tbx_tech->setText(filePath);
        QFile f_read(filePath);
        if (!f_read.open(QFile::ReadOnly | QFile::Text)){}
        QTextStream in(&f_read);
        full = in.readAll();
        f_read.close();
        full_lst=full.split("\n");
        QMessageBox msb;
        msb.setText(full_lst.value(0));
        //msb.exec();

        msb.setText(full_lst.value(1));
        //msb.exec();

        for(int i=0;i<full_lst.length()-1;i++){
            temp=full_lst.value(i);
            QStringList r_value=temp.split(",");
            if(i==0){
                header_value=r_value;
                for(int jj=0;jj<r_value.length();jj++){
                    QStandardItem *header=new QStandardItem(QString(r_value.value(jj)));
                    mod->setHorizontalHeaderItem(jj,header);
                }
            }
            else{
                for(int jj=0;jj<r_value.length();jj++){
                    QStandardItem *itm = new QStandardItem(QString(r_value.value(jj)));
                    mod->setItem(i-1,jj,itm);
                }
            }

        }
        ui->tv_csv_table->setModel(mod);

        //__________________________________________________________________________________________
        sz=ui->tv_csv_table->model()->rowCount(QModelIndex());
        for(int i=0;i<sz;i++){
            q_insert_statement="INSERT INTO `ngo`.`"+lst_tbl.value(j)+"` (";
            q_insert_statement+="`"+header_value.value(0)+"`";
            for(int jj=1;jj<header_value.length();jj++){
                q_insert_statement+=",`"+header_value.value(jj)+"`";
            }
            q_insert_statement+=") VALUES(";

            ind=ui->tv_csv_table->model()->index(i,0,QModelIndex());
            q_insert_statement+="'"+ui->tv_csv_table->model()->data(ind).toString()+"'";
            for(int jj=1;jj<header_value.length();jj++){
                ind=ui->tv_csv_table->model()->index(i,jj,QModelIndex());
                q_insert_statement+=",'"+ui->tv_csv_table->model()->data(ind).toString()+"'";
            }
            q_insert_statement+=")";
            dbs.queryfeeder(q_insert_statement);
            ui->progressBar->setValue((i*100)/sz);
        }
    }
    ui->progressBar->setValue(100);
}


void form_dash::on_btn_tranc_clicked()
{
    dbsclass dbs;
    QString q;



    QString q_tbl_list="collection,employee,loan,member,diposit,payment";
    QStringList lst_tbl=q_tbl_list.split(",");
    //dbs.tv_display(ui->tv_csv_table,q_tbl_list);

    for(int i=0;i<lst_tbl.size();i++){
        q="truncate ngo."+lst_tbl.value(i)+"";
        dbs.queryfeeder(q);
    }
}


void form_dash::on_btn_upload_clicked()
{
    QString filePath;

    filePath=QFileDialog::getExistingDirectory(this,tr("Open File"), QDir::currentPath());
    ui->tbx_tech->setText(filePath+"/");
}


void form_dash::on_btn_backup_clicked()
{
    ui->btn_export->click();
}

void form_dash::on_btn_restore_clicked()
{
    ui->btn_tranc->click();
    ui->btn_import->click();
}

void form_dash::on_btn_employee_clicked()
{
    form_employee *m=new form_employee(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_dash::on_ctbx_diposit_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q2;
    if(arg1=="Diposit"){
        q2="SELECT id as Diposit_Id,member as Member_id,id as Due_Percentage,(SELECT Name FROM ngo.member where id=diposit.member) as Name,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,payment as Installment_Cost,gap,((payment+0)*((DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)/(gap+0))) as Comited_Amount,(select sum(payment_amount) as ss from ngo.payment where diposit=diposit.id) as Paid_Amount,((((payment+0)*((DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)/(gap+0)))+0)-((select sum(payment_amount) as ss from ngo.payment where diposit=diposit.id)+0)) as Due,(100-((((select sum(payment_amount) as ss from ngo.payment where diposit=diposit.id)+0)/(((payment+0)*((DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)/(gap+0)))+0))*100)) as percentage FROM ngo.diposit";
        dbs.tv_display(ui->tv_diposit,q2);
        ui->tv_diposit->resizeColumnsToContents();

        for(int i=0;i<dbs.tbl_sz(q2);i++){
            QProgressBar *prog=new QProgressBar();

            QModelIndex in=ui->tv_diposit->model()->index(i,13,QModelIndex());
            QString val=ui->tv_diposit->model()->data(in).toString();
            QModelIndex in2=ui->tv_diposit->model()->index(i,2,QModelIndex());
            prog->setValue(val.toDouble());
            prog->setTextVisible(true);
            ui->tv_diposit->setIndexWidget(in2,prog);
        }

        ui->tbx_comited->setText(QString::number(dbs.fill_array(q2,10),'g',12));
        ui->tbx_paid->setText(QString::number(dbs.fill_array(q2,11),'g',12));
        ui->tbx_diposit_due->setText(QString::number(dbs.fill_array(q2,12),'g',12));
    }
    else if(arg1=="Member"){
        q2="SELECT member as Member_id,id as Due_Percentage,(SELECT Name FROM ngo.member where id=diposit.member) as Name,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,sum(amount) as Amount,sum(((payment+0)*((DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)/(gap+0)))) as Comited_Amount,(select sum(payment_amount) as ss from ngo.payment where diposit In((SELECT id FROM ngo.diposit where member=Member_id))) as Paid_Amount,((sum(((payment+0)*((DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)/(gap+0))))+0)-((select sum(payment_amount) as ss from ngo.payment where diposit In((SELECT id FROM ngo.diposit where member=Member_id)))+0)) as Due,(100-((((select sum(payment_amount) as ss from ngo.payment where diposit In((SELECT id FROM ngo.diposit where member=Member_id)))+0)/(sum(((payment+0)*((DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)/(gap+0))))+0))*100)) as percentage FROM ngo.diposit group by Member_id";
        dbs.tv_display(ui->tv_diposit,q2);
        ui->tv_diposit->resizeColumnsToContents();

        for(int i=0;i<dbs.tbl_sz(q2);i++){
            QProgressBar *prog=new QProgressBar();

            QModelIndex in=ui->tv_diposit->model()->index(i,9,QModelIndex());
            QString val=ui->tv_diposit->model()->data(in).toString();
            QModelIndex in2=ui->tv_diposit->model()->index(i,1,QModelIndex());
            prog->setValue(val.toDouble());
            prog->setTextVisible(true);
            ui->tv_diposit->setIndexWidget(in2,prog);
        }

        ui->tbx_comited->setText(QString::number(dbs.fill_array(q2,6),'g',12));
        ui->tbx_paid->setText(QString::number(dbs.fill_array(q2,7),'g',12));
        ui->tbx_diposit_due->setText(QString::number(dbs.fill_array(q2,8),'g',12));
    }
    //(100/(ui->tbx_ret_amo->text().toDouble()/ui->tbx_col_amo->text().toDouble()))
    ui->rnd_diposit->setValue(100-((ui->tbx_paid->text().toDouble()/ui->tbx_comited->text().toDouble())*100));
}

void form_dash::on_ctbx_diposit_notification_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q,sd,ed;
    QDate e_dat=QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"),s_dat;
    ed=e_dat.toString("yyyy-MM-dd");
    if(arg1=="Todays Payment"){
        q="SELECT id as Diposit_Id,member as Member_id,(SELECT Name FROM ngo.member where id=diposit.member) as Name,(SELECT Phone FROM ngo.member where id=diposit.member) as Phone_Number, DATE_FORMAT(now(), '%Y-%m-%d') as Today,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed FROM ngo.diposit where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)%gap+0=0";
        //QString q1="SELECT DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),STR_TO_DATE(opening_date, '%d/%m/%y')) as ddd  FROM ngo.loan ";

    }

    dbs.tv_display(ui->tv_todays_collection_diposit,q);
}
