#ifndef FORM_VISUALIZATION_H
#define FORM_VISUALIZATION_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>
#include<QStandardItem>


namespace Ui {
class form_visualization;
}

class form_visualization : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_visualization(QString id);
    ~form_visualization();
    
private slots:
    void on_ctbx_member_editTextChanged(const QString &arg1);

    void on_btn_cancel_clicked();

    void on_ctbx_rev_type_editTextChanged(const QString &arg1);

    void on_ctbx_ext_duration_type_editTextChanged(const QString &arg1);

    void on_ctnx_loan_editTextChanged(const QString &arg1);

    void on_ctbx_member_3_editTextChanged(const QString &arg1);

    void on_ctbx_member_name_editTextChanged(const QString &arg1);

    void on_tv_rev_member_doubleClicked(const QModelIndex &index);

    void on_tv_busnessStatus_doubleClicked(const QModelIndex &index);

    void on_tv_loan_doubleClicked(const QModelIndex &index);

    void on_tv_member_loan_doubleClicked(const QModelIndex &index);

    void on_tv_ext_missdate_doubleClicked(const QModelIndex &index);

    void on_btn_pie_member_clicked();

    void on_btn_bar_member_clicked();

    void on_btn_pie_rev_loan_clicked();

    void on_btn_bar_rev_loan_clicked();

    void on_btn_pie_rev_member_clicked();

    void on_btn_bar_rev_member_clicked();

    void on_ctnx_rev_member_limit_editTextChanged(const QString &arg1);

    void on_ctbx_rev_loan_editTextChanged(const QString &arg1);

    void on_ctbx_loan_details_coll_type_editTextChanged(const QString &arg1);

    void on_btn_pie_loan_details_clicked();

    void on_btn_bar_loan_details_clicked();

    void on_btn_pie_ext_clicked();

    void on_btn_bar_ext_clicked();

    void on_ctbx_member_coll_editTextChanged(const QString &arg1);

    void on_tbx_member_loan_textChanged(const QString &arg1);

private:
    Ui::form_visualization *ui;
};

#endif // FORM_VISUALIZATION_H
