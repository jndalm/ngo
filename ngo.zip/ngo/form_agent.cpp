#include "form_agent.h"
#include "ui_form_agent.h"

form_agent::form_agent(QString id) :
    ui(new Ui::form_agent)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);

    dbsclass dbs;
    ui->lbl_emp_id->setText(id);
    dbs.fill_label(ui->lbl_emp_name,"SELECT name FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);
    ui->tbx_phone->setValidator(new QDoubleValidator(0, 200, 2, this));

    dbs.tv_display(ui->tv_customer,"select * from ngo.member");

    //date setting
    //ui->dbx_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->dbx_joining_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));

    //ui->tbx_id->setText("");
    ui->tbx_name->setText("");
    ui->tbx_add->setText("");
    ui->tbx_phone->setText("");
    ui->tbx_email->setText("");

    ui->tbx_name->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z ]{2,60}\\b")));
    ui->tbx_add->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z ]{2,60}\\b")));
    // ui->tbx_phone->setValidator(new QRegExpValidator(QRegExp("\\b[0-9]{2,15}\\b")));
    ui->tbx_email->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,5}\\b")));
    ui->tbx_add->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z -/,]{2,60}\\b")));

    ui->btn_clear->click();



    QString q22="select grp from ngo.member group by grp";
    dbs.fill_combobox(ui->ctbx_group,q22);
}

form_agent::~form_agent()
{
    delete ui;
}



void form_agent::on_ctbx_type_editTextChanged(const QString &arg1)
{
    dbsclass dbs;

    //LOA
    QString loa=dbs.fill_string("SELECT loa FROM spl.employee where id='"+ui->lbl_emp_id->text()+"'",0);

    if(arg1=="All"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent");
    }

    else if(arg1=="Approval Pending"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent where approve_status='Pending'");
    }
    else if(arg1=="Check Pending"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent where check_status='Pending'");
    }
    else if(arg1=="Activation Pending"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent where activate_status='D'");
    }


    else if(arg1=="Approved"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent where approve_status='Approved'");
    }
    else if(arg1=="Checked"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent where check_status='Checked'");
    }
    else if(arg1=="Activate"){
        dbs.tv_display(ui->tv_customer,"select * from spl.agent where activate_status='A'");
    }

    else{
        if(loa=="4"){
            dbs.tv_display(ui->tv_customer,"select * from spl.agent where check_status='Checked' and approve_status='Pending'");

        }
        else if(loa=="5"){
            dbs.tv_display(ui->tv_customer,"select * from spl.agent where check_status='Pending'");
        }
    }
}

void form_agent::on_btn_submit_clicked()
{

    int sz;

    QModelIndex index;
    dbsclass dbs;
    QString blb=":IMAGE";
    QString qry="INSERT INTO ngo.member(Name, Phone, address, email,joining_date, joining_fee, added_by,grp,img) VALUES('"+ui->tbx_name->text()+"','"+ui->tbx_phone->text()+"','"+ui->tbx_add->text()+"','"+ui->tbx_email->text()+"','"+ui->dbx_joining_date->text()+"','"+ui->tbx_joining_fee->text()+"','"+ui->lbl_emp_id->text()+"','"+ui->ctbx_group->currentText()+"',:IMAGE)";

    QString strPatt = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
    QRegExp rx(strPatt);
    if(! rx.exactMatch(ui->tbx_email->text()) && ui->tbx_email->text()!=""){
        QMessageBox msg;
        msg.setText("Invalid Email!!!!");
        msg.exec();
        ui->tbx_email->setFocus();
    }
    else{
        if(ui->tbx_name->text()==""||ui->tbx_add->text()==""||ui->tbx_phone->text()==""||ui->tbx_email->text()==""){
            QMessageBox msgBox;
            msgBox.setText("Field is empty.");
            msgBox.setInformativeText("Do you want to continue?");
            msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
            msgBox.setDefaultButton(QMessageBox::Ok);
            int ret = msgBox.exec();
            switch (ret) {
            case QMessageBox::Ok:
                dbs.queryfeeder(ui->tbx_id,qry,ba,blb);
                dbs.tv_display(ui->tv_customer,"select * from ngo.member");

                sz=ui->tv_customer->model()->rowCount(QModelIndex());
                for(int i=0;i<sz;i++){
                    index=ui->tv_customer->model()->index(i,0,QModelIndex());
                    if(ui->tv_customer->model()->data(index).toString()==ui->tbx_id->text()){
                        ui->tv_customer->selectRow(i);
                        ui->tv_customer->scrollTo(index);
                    }
                }
                break;

            case QMessageBox::Cancel:
                break;

            }
        }
        else{

            dbs.queryfeeder(ui->tbx_id,qry,ba,blb);
            dbs.tv_display(ui->tv_customer,"select * from ngo.member");

            sz=ui->tv_customer->model()->rowCount(QModelIndex());
            for(int i=0;i<sz;i++){
                index=ui->tv_customer->model()->index(i,0,QModelIndex());
                if(ui->tv_customer->model()->data(index).toString()==ui->tbx_id->text()){
                    ui->tv_customer->selectRow(i);
                    ui->tv_customer->scrollTo(index);
                }
            }
        }


        ui->btn_clear->click();

    }
}

void form_agent::on_btn_cancel_clicked()
{
    form_dash *m=new form_dash(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_agent::on_tv_customer_clicked(const QModelIndex &index)
{
    QModelIndex indx,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11,index12,index13,index14,index15,index16;

    indx=ui->tv_customer->model()->index(index.row(),0,QModelIndex());
    index2=ui->tv_customer->model()->index(index.row(),2,QModelIndex());
    index3=ui->tv_customer->model()->index(index.row(),3,QModelIndex());
    index4=ui->tv_customer->model()->index(index.row(),4,QModelIndex());
    index5=ui->tv_customer->model()->index(index.row(),5,QModelIndex());
    index6=ui->tv_customer->model()->index(index.row(),6,QModelIndex());
    index7=ui->tv_customer->model()->index(index.row(),7,QModelIndex());
    index8=ui->tv_customer->model()->index(index.row(),8,QModelIndex());
    index9=ui->tv_customer->model()->index(index.row(),9,QModelIndex());
    index10=ui->tv_customer->model()->index(index.row(),1,QModelIndex());

    QString b=ui->tv_customer->model()->data(indx).toString();
    QString d=ui->tv_customer->model()->data(index2).toString();
    QString p=ui->tv_customer->model()->data(index3).toString();
    QString cs=ui->tv_customer->model()->data(index4).toString();
    QString cp=ui->tv_customer->model()->data(index5).toString();
    QString q=ui->tv_customer->model()->data(index6).toString();
    QString a=ui->tv_customer->model()->data(index7).toString();
    QString w=ui->tv_customer->model()->data(index8).toString();
    QString name=ui->tv_customer->model()->data(index10).toString();

    QString s=ui->tv_customer->model()->data(index9).toString();

    ui->tbx_id->setText(b);
    ui->tbx_name->setText(name);
    ui->tbx_phone->setText(d);
    ui->tbx_add->setText(p);
    ui->tbx_email->setText(cs);

    ui->tbx_joining_fee->setText(a);
    ui->ctbx_group->setEditText(w);
    QDate dat;
    if(cp.size()>8){
        dat=QDate::fromString(cp,"dd.MM.yyyy");}
    else{
        dat=QDate::fromString(cp,"dd.MM.yy");
    }

    ui->dbx_joining_date->setDate(dat);

    QString qq="select * from ngo.member where id='"+ui->tbx_id->text()+"'";
    dbsclass dbs;
    ba=dbs.fill_blob(qq,9);

    QPixmap pm;
    pm.loadFromData(ba);
    ui->lbl_image->setPixmap(pm);
    ui->lbl_image->setScaledContents( true );
    ui->lbl_image->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
}

void form_agent::on_tbx_search_textChanged(const QString &arg1)
{
    dbsclass dbs;
    dbs.search_tv(arg1,ui->tv_customer);
}

void form_agent::on_btn_submit_2_clicked()
{

    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.member set Name='"+ui->tbx_name->text()+"',address='"+ui->tbx_add->text()+"',Phone='"+ui->tbx_phone->text()+"',email='"+ui->tbx_email->text()+"', joining_date='"+ui->dbx_joining_date->text()+"',  joining_fee='"+ui->tbx_joining_fee->text()+"', grp='"+ui->ctbx_group->currentText()+"',img=:IMAGE where id='"+ui->tbx_id->text()+"'";
    QString blb=":IMAGE";
    dbs.queryfeeder(q,ba,blb);
    dbs.tv_display(ui->tv_customer,"select * from ngo.member");

    sz=ui->tv_customer->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_customer->model()->index(i,0,QModelIndex());
        if(ui->tv_customer->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_customer->selectRow(i);
            ui->tv_customer->scrollTo(index);
        }
    }
    ui->btn_clear->click();
}

void form_agent::on_btn_remove_clicked()
{
    QString q="DELETE FROM ngo.member WHERE id='"+ui->tbx_id->text()+"'";
    dbsclass dbs;
    dbs.queryfeeder(q);
    dbs.tv_display(ui->tv_customer,"select * from ngo.member");


    ui->btn_clear->click();
}

void form_agent::on_btn_cancel_2_clicked()
{
    dbsclass dbs;
    dbs.print_pdf(ui->tv_customer,"Agent");
}

void form_agent::on_btn_export_customer_csv_clicked()
{
    dbsclass dbs;
    dbs.csv_exp("Member Details:",ui->tv_customer);
}



void form_agent::on_btn_clear_clicked()
{
    dbsclass dbs;
    ui->tbx_id->setText("Generated By System...");

    ui->tbx_id->setText("");
    ui->tbx_name->setText("");
    ui->tbx_phone->setText("");
    ui->tbx_add->setText("");
    ui->tbx_email->setText("");
    // QString d=dbs.recent_date();
    ui->dbx_joining_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
}

void form_agent::on_btn_upload_image_clicked()
{
    QString filePath;

    //filePath=QFileDialog::getOpenFileName(this,tr("Open File"), QDir::currentPath());
    filePath = QFileDialog::getOpenFileName(this,tr("Btouse Image"),".",tr("Image Files (*.png *.jpg *.jpeg *.bmp)"));

    ui->tbx_image->setText(filePath);
    QFile f(filePath);
    if(f.open(QIODevice::ReadOnly))
    {
        ba = f.readAll();
        f.close();
    }
    QPixmap pm;
    pm.load(filePath);
    ui->lbl_image->setPixmap(pm);
    ui->lbl_image->setScaledContents( true );
    ui->lbl_image->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
}
