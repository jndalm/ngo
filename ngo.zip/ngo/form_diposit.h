#ifndef FORM_DIPOSIT_H
#define FORM_DIPOSIT_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>
#include <QLabel>

namespace Ui {
class form_diposit;
}

class form_diposit : public QWidget
{
    Q_OBJECT

public:
    explicit form_diposit(QString id);
    ~form_diposit();

private slots:
    void on_btn_submit_clicked();

    void on_btn_update_clicked();

    void on_btn_remove_clicked();

    void on_btn_clear_clicked();

    void on_tv_customer_clicked(const QModelIndex &index);

    void on_btn_cancel_clicked();

    void on_tbx_search_textChanged(const QString &arg1);

    void on_btn_export_customer_csv_clicked();

    void on_tbx_interest_textChanged(const QString &arg1);

    void on_dbx_opening_date_dateChanged(const QDate &date);

    void on_tbx_amount_textChanged(const QString &arg1);

    void on_tbx_gap_per_inst_textChanged(const QString &arg1);

    void on_ctbx_member_editTextChanged(const QString &arg1);

    void on_ctbx_member_name_editTextChanged(const QString &arg1);

private:
    Ui::form_diposit *ui;
};

#endif // FORM_DIPOSIT_H
