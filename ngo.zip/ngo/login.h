#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>

#include<dbsclass.h>
#include<form_agent.h>
#include<QMessageBox>
#include<QDesktopWidget>
#include<QKeyEvent>

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT
    
public:
    explicit login(QWidget *parent = 0);
    ~login();
    void keyPressEvent(QKeyEvent *);

    
private slots:
    void on_btn_login_clicked();

    void on_tbx_id_returnPressed();

    void on_tbx_pass_returnPressed();

    void on_btn_cancel_clicked();

    void on_tbx_host_returnPressed();

    void on_tbx_port_returnPressed();

    void on_tbx_db_name_returnPressed();

    void on_tbx_db_user_returnPressed();

    void on_tbx_db_pass_returnPressed();

    void on_btn_setup_clicked();

    void on_btn_hide_clicked();

private:
    Ui::login *ui;
};

#endif // LOGIN_H
