#ifndef FORM_EMPLOYEE_H
#define FORM_EMPLOYEE_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>


namespace Ui {
class form_employee;
}

class form_employee : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_employee(QString id);
    ~form_employee();
    
private slots:
    void on_btn_submit_clicked();

    void on_btn_submit_2_clicked();

    void on_btn_remove_clicked();

    void on_btn_export_emp_details_clicked();

    void on_tv_emp_clicked(const QModelIndex &index);

    void on_btn_cancel_clicked();

    void on_btn_approve__clicked();

    void on_btn_decline_clicked();

    void on_btn_check_clicked();

    void on_btn_reject_clicked();

    void on_btn_activate_clicked();

    void on_btn_deactivate_clicked();

    void on_ctbx_type_editTextChanged(const QString &arg1);

    void on_btn_clear_clicked();

private:
    Ui::form_employee *ui;
};

#endif // FORM_EMPLOYEE_H
