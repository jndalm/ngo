#ifndef PIEPLOT_H
#define PIEPLOT_H

#define HISTORY 1

#include <qwt/qwt_plot.h>

class QwtPlotCurve;

class PiePlot: public QwtPlot
{
    Q_OBJECT
public:
    PiePlot(QStringList pieNames, QVector<QColor> pieColors, int sizeOfPie = 300, QWidget * = 0);
    ~PiePlot();
    const QwtPlotCurve *pieCurve(int id) const
    { return data[id].curve; }
    void plotStaticValues(QVector<double> *inputData);
    private Q_SLOTS:
    void showCurve(QwtPlotItem *, bool on);
    private:
    struct pieCurves
    {
    QwtPlotCurve *curve;
    double data[HISTORY];
    } * data;
    double timeData[HISTORY];
    int dataCount;
    int numPlots;
};

#endif // PIEPLOT_H
