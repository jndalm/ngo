#ifndef PIEMARKER_H
#define PIEMARKER_H


#include <qwt/qwt_plot_item.h>

class PieMarker: public QwtPlotItem
{
private:
    int height;
    int width;
    int margin;
    int numPlots;


public:
    PieMarker(int numPlots, int size);
    virtual int rtti() const;
    virtual void draw(QPainter *p,
    const QwtScaleMap &, const QwtScaleMap &,
    const QRectF &rect) const;
};

#endif // PIEMARKER_H
