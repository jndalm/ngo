#ifndef FORM_DAILY_COLLECTION_H
#define FORM_DAILY_COLLECTION_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>

namespace Ui {
class form_daily_collection;
}

class form_daily_collection : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_daily_collection(QString id);
    ~form_daily_collection();
    
private slots:
    void on_ctbx_loan_no_editTextChanged(const QString &arg1);

    void on_tv_customer_clicked(const QModelIndex &index);

    void on_tbx_payment_3_textChanged(const QString &arg1);

    void on_btn_submit_clicked();

    void on_btn_clear_clicked();

    void on_tv_daily_collection_clicked(const QModelIndex &index);

    void on_btn_update_clicked();

    void on_btn_remove_clicked();

    void on_btn_cancel_clicked();

    void on_dbx_installment_date_dateChanged(const QDate &date);

    void on_ctbx_member_editTextChanged(const QString &arg1);

    void on_ctbx_member_2_editTextChanged(const QString &arg1);

    void on_tbx_member_textChanged(const QString &arg1);

private:
    Ui::form_daily_collection *ui;
};

#endif // FORM_DAILY_COLLECTION_H

