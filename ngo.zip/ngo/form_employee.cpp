#include "form_employee.h"
#include "ui_form_employee.h"

form_employee::form_employee(QString id) :
    ui(new Ui::form_employee)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);
     dbsclass dbs;
    ui->dbx_joining_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));

    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);


    ui->lbl_emp_id->setText(id);
    dbs.fill_label(ui->lbl_emp_name,"SELECT name FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);

    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    ui->btn_clear->click();

    ui->tbx_phone->setValidator(new QDoubleValidator(0, 200, 2, this));
    ui->tbx_salary->setValidator(new QDoubleValidator(0, 200, 8, this));
    ui->tbx_name->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z ]{2,60}\\b")));
    ui->tbx_email->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,5}\\b")));
    ui->tbx_add->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9/#-, ]{2,100}\\b")));
    ui->tbx_phone->setValidator(new QRegExpValidator(QRegExp("\\b[0-9+-]{2,12}\\b")));
    ui->tbx_rank->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9]{2,40}\\b")));
    ui->tbx_salary->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9]{2,10}\\b")));
    ui->tbx_loa->setValidator(new QRegExpValidator(QRegExp("\\b[A-a-z0-9]{2,10}\\b")));
    ui->tbx_search->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z ]{2,60}\\b")));

    //LOA
    QString loa=dbs.fill_string("SELECT loa FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);
    if(loa=="2"){
        ui->tbx_approve_remarks->setHidden(true);
        ui->lbl_approve_remarks->setHidden(true);
        ui->btn_approve_->setHidden(true);
        ui->btn_decline->setHidden(true);

        ui->tbx_check_remarks->setHidden(true);
        ui->lbl_check_remarks->setHidden(true);
        ui->btn_check->setHidden(true);
        ui->btn_reject->setHidden(true);

        ui->tbx_remarks_activate->setHidden(true);
        ui->lbl_remarks_activate->setHidden(true);
        ui->btn_activate->setHidden(true);
        ui->btn_deactivate->setHidden(true);

        ui->btn_remove->setHidden(true);
        ui->ctbx_type->setHidden(true);
    }
    else if(loa=="4"){

        ui->tbx_check_remarks->setHidden(true);
        ui->lbl_check_remarks->setHidden(true);
        ui->btn_check->setHidden(true);
        ui->btn_reject->setHidden(true);

        ui->tbx_remarks_activate->setHidden(true);
        ui->lbl_remarks_activate->setHidden(true);
        ui->btn_activate->setHidden(true);
        ui->btn_deactivate->setHidden(true);

        ui->btn_submit->setHidden(true);
        ui->btn_submit_2->setHidden(true);
        ui->btn_remove->setHidden(true);
    }
    else if(loa=="5"){
        ui->tbx_approve_remarks->setHidden(true);
        ui->lbl_approve_remarks->setHidden(true);
        ui->btn_approve_->setHidden(true);
        ui->btn_decline->setHidden(true);

        ui->tbx_remarks_activate->setHidden(true);
        ui->lbl_remarks_activate->setHidden(true);
        ui->btn_activate->setHidden(true);
        ui->btn_deactivate->setHidden(true);

        ui->btn_submit->setHidden(true);
        ui->btn_submit_2->setHidden(true);
        ui->btn_remove->setHidden(true);
    }
}

form_employee::~form_employee()
{
    delete ui;
}



void form_employee::on_ctbx_type_editTextChanged(const QString &arg1)
{
    dbsclass dbs;

    //LOA
    QString loa=dbs.fill_string("SELECT loa FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);

    if(arg1=="All"){
        dbs.tv_display(ui->tv_emp,"select * from ngo.employee");
    }
    else{
        if(loa=="4"){
            dbs.tv_display(ui->tv_emp,"select * from ngo.employee where check_status='Checked' and approve_status='Pending'");

        }
        else if(loa=="5"){
            dbs.tv_display(ui->tv_emp,"select * from ngo.employee where check_status='Pending'");
        }
    }
}

void form_employee::on_btn_submit_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString qry="insert into ngo.employee (name,address,phone,email,password,designation,salary,loa,joining_date,added_by)values('"+ui->tbx_name->text()+"','"+ui->tbx_add->text()+"','"+ui->tbx_phone->text()+"','"+ui->tbx_email->text()+"','"+ui->tbx_pass->text()+"','"+ui->tbx_rank->text()+"','"+ui->tbx_salary->text()+"','"+ui->tbx_loa->text()+"','"+ui->dbx_joining_date->text()+"','"+ui->lbl_emp_id->text()+"')";

    QString strPatt = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
    QRegExp rx(strPatt);
    if(! rx.exactMatch(ui->tbx_email->text())){
        QMessageBox msg;
        msg.setText("Invalid Email!!!!");
        msg.exec();
        ui->tbx_email->setFocus();
    }
    else{
        if(ui->tbx_name->text()==""||ui->tbx_add->text()==""||ui->tbx_phone->text()==""||ui->tbx_email->text()==""||ui->tbx_pass->text()==""||ui->tbx_rank->text()==""||ui->tbx_salary->text()==""||ui->tbx_loa->text()==""){
            QMessageBox msgBox;
            QString q_d;
            msgBox.setText("Field is empty.");
            msgBox.setInformativeText("Do you want to continue?");
            msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
            msgBox.setDefaultButton(QMessageBox::Ok);
            int ret = msgBox.exec();
            switch (ret) {
            case QMessageBox::Ok:
                dbs.queryfeeder(ui->tbx_id,qry);
                q_d="select * from ngo.employee";
                dbs.tv_display(ui->tv_emp,q_d);

                sz=ui->tv_emp->model()->rowCount(QModelIndex());
                for(int i=0;i<sz;i++){
                    index=ui->tv_emp->model()->index(i,0,QModelIndex());
                    if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
                        ui->tv_emp->selectRow(i);
                        ui->tv_emp->scrollTo(index);
                    }
                }
                ui->tbx_id->setText("Generated By System. . . .");
                ui->tbx_name->setText("");
                ui->tbx_add->setText("");
                ui->tbx_phone->setText("");
                ui->tbx_email->setText("");
                ui->tbx_pass->setText("");
                ui->tbx_rank->setText("");
                ui->tbx_salary->setText("");
                ui->tbx_loa->setText("");

                break;

            case QMessageBox::Cancel:
                break;

            }
        }
        else{

            dbs.queryfeeder(ui->tbx_id,qry);

            QString q_d="select * from ngo.employee";
            dbs.tv_display(ui->tv_emp,q_d);

            sz=ui->tv_emp->model()->rowCount(QModelIndex());
            for(int i=0;i<sz;i++){
                index=ui->tv_emp->model()->index(i,0,QModelIndex());
                if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
                    ui->tv_emp->selectRow(i);
                    ui->tv_emp->scrollTo(index);
                }
            }
            ui->tbx_id->setText("Generated By System. . . .");
            ui->tbx_name->setText("");
            ui->tbx_add->setText("");
            ui->tbx_phone->setText("");
            ui->tbx_email->setText("");
            ui->tbx_pass->setText("");
            ui->tbx_rank->setText("");
            ui->tbx_salary->setText("");
            ui->tbx_loa->setText("");
        }


    }
}

void form_employee::on_btn_submit_2_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set name='"+ui->tbx_name->text()+"',address='"+ui->tbx_add->text()+"',phone='"+ui->tbx_phone->text()+"',email='"+ui->tbx_email->text()+"',password='"+ui->tbx_pass->text()+"',designation='"+ui->tbx_rank->text()+"',salary='"+ui->tbx_salary->text()+"',loa='"+ui->tbx_loa->text()+"',joining_date='"+ui->dbx_joining_date->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }

    ui->tbx_id->setText("Generated By System. . . .");
    ui->tbx_name->setText("");
    ui->tbx_add->setText("");
    ui->tbx_phone->setText("");
    ui->tbx_email->setText("");
    ui->tbx_pass->setText("");
    ui->tbx_rank->setText("");
    ui->tbx_salary->setText("");
    ui->tbx_loa->setText("");
}

void form_employee::on_btn_remove_clicked()
{
    QString q="DELETE FROM `spl`.`employee` WHERE id='"+ui->tbx_id->text()+"'";
    dbsclass dbs;
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    ui->tbx_id->setText("Generated By System. . . .");
    ui->tbx_name->setText("");
    ui->tbx_add->setText("");
    ui->tbx_phone->setText("");
    ui->tbx_email->setText("");
    ui->tbx_pass->setText("");
    ui->tbx_rank->setText("");
    ui->tbx_salary->setText("");
    ui->tbx_loa->setText("");
}

void form_employee::on_btn_export_emp_details_clicked()
{
    QString rep="employee details\n\n";
    dbsclass dbs;
    dbs.csv_exp(rep,ui->tv_emp);
}

void form_employee::on_tv_emp_clicked(const QModelIndex &index)
{
    QModelIndex ind=ui->tv_emp->model()->index(index.row(),0,QModelIndex());
    QString val=ui->tv_emp->model()->data(ind).toString();
    QString q="select * from ngo.employee where id='"+val+"'";
    dbsclass dbs;
    dbs.fill_tbx(ui->tbx_id,q,0);
    dbs.fill_tbx(ui->tbx_name,q,1);
    dbs.fill_tbx(ui->tbx_add,q,4);
    dbs.fill_tbx(ui->tbx_phone,q,5);
    dbs.fill_tbx(ui->tbx_email,q,6);
    dbs.fill_tbx(ui->tbx_pass,q,2);
    dbs.fill_tbx(ui->tbx_rank,q,3);
    dbs.fill_tbx(ui->tbx_salary,q,12);
    dbs.fill_tbx(ui->tbx_loa,q,7);
    QDate dat=QDate::fromString(dbs.fill_string(q,8),"dd.MM.yyyy");
    ui->dbx_joining_date->setDate(dat);
}

void form_employee::on_btn_cancel_clicked()
{
    form_dash *m=new form_dash(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_employee::on_btn_approve__clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set approve_by='"+ui->lbl_emp_id->text()+"',approve_status='Approved',approve_remarks='"+ui->tbx_approve_remarks->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }


    ui->btn_clear->click();
}


void form_employee::on_btn_decline_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set approve_by='"+ui->lbl_emp_id->text()+"',approve_status='Declined',approve_remarks='"+ui->tbx_approve_remarks->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }


    ui->btn_clear->click();
}


void form_employee::on_btn_check_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set check_by='"+ui->lbl_emp_id->text()+"',check_status='Checked',check_remarks='"+ui->tbx_check_remarks->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }


    ui->btn_clear->click();
}

void form_employee::on_btn_reject_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set check_by='"+ui->lbl_emp_id->text()+"',check_status='Rejected',check_remarks='"+ui->tbx_check_remarks->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }


    ui->btn_clear->click();
}

void form_employee::on_btn_activate_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set activate_by='"+ui->lbl_emp_id->text()+"',activate_status='A',activate_remarks='"+ui->tbx_remarks_activate->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }


    ui->btn_clear->click();
}


void form_employee::on_btn_deactivate_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.employee set activate_by='"+ui->lbl_emp_id->text()+"',activate_status='D',activate_remarks='"+ui->tbx_remarks_activate->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    QString q_d="select * from ngo.employee";
    dbs.tv_display(ui->tv_emp,q_d);

    sz=ui->tv_emp->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_emp->model()->index(i,0,QModelIndex());
        if(ui->tv_emp->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_emp->selectRow(i);
            ui->tv_emp->scrollTo(index);
        }
    }

    ui->btn_clear->click();
}

void form_employee::on_btn_clear_clicked()
{
     dbsclass dbs;
    ui->tbx_id->setText("Generated By System. . . .");
    ui->tbx_name->setText("");
    ui->tbx_add->setText("");
    ui->tbx_phone->setText("");
    ui->tbx_email->setText("");
    ui->tbx_pass->setText("");
    ui->tbx_rank->setText("");
    ui->tbx_salary->setText("");
    ui->tbx_loa->setText("");
    ui->dbx_joining_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
}
