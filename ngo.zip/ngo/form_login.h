#ifndef FORM_LOGIN_H
#define FORM_LOGIN_H

#include <QWidget>

namespace Ui {
class form_login;
}

class form_login : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_login(QWidget *parent = 0);
    ~form_login();
    
private:
    Ui::form_login *ui;
};

#endif // FORM_LOGIN_H
