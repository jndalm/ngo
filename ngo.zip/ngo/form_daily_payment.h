#ifndef FORM_DAILY_PAYMENT_H
#define FORM_DAILY_PAYMENT_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>

namespace Ui {
class form_daily_payment;
}

class form_daily_payment : public QWidget
{
    Q_OBJECT

public:
    explicit form_daily_payment(QString id);
    ~form_daily_payment();

private slots:
    void on_btn_cancel_clicked();

    void on_btn_update_clicked();

    void on_btn_remove_clicked();

    void on_btn_clear_clicked();

    void on_btn_export_customer_csv_clicked();

    void on_tbx_search_textChanged(const QString &arg1);

    void on_tbx_search_2_textChanged(const QString &arg1);

    void on_ctbx_member_2_editTextChanged(const QString &arg1);

    void on_ctbx_member_editTextChanged(const QString &arg1);

    void on_dbx_payment_date_dateChanged(const QDate &date);

    void on_tv_daily_payment_clicked(const QModelIndex &index);

    void on_btn_submit_clicked();

    void on_tbx_payment_3_textChanged(const QString &arg1);

    void on_tv_customer_clicked(const QModelIndex &index);

    void on_ctbx_diposit_no_editTextChanged(const QString &arg1);

private:
    Ui::form_daily_payment *ui;
};

#endif // FORM_DAILY_PAYMENT_H
