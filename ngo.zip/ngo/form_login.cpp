#include "form_login.h"
#include "ui_form_login.h"

form_login::form_login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::form_login)
{
    ui->setupUi(this);
}

form_login::~form_login()
{
    delete ui;
}
