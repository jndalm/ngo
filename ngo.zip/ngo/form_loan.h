#ifndef FORM_LOAN_H
#define FORM_LOAN_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>

namespace Ui {
class form_loan;
}

class form_loan : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_loan(QString id);
    ~form_loan();
    
private slots:
    void on_btn_submit_clicked();

    void on_btn_update_clicked();

    void on_btn_remove_clicked();

    void on_btn_cancel_clicked();

    void on_tv_customer_clicked(const QModelIndex &index);

    void on_btn_clear_clicked();

    void on_tbx_search_textChanged(const QString &arg1);

    void on_btn_export_customer_csv_clicked();

    void on_tbx_interest_textChanged(const QString &arg1);

    void on_tbx_duration_textChanged(const QString &arg1);

    void on_dbx_closing_date_dateChanged(const QDate &date);

    void on_dbx_opening_date_dateChanged(const QDate &date);

    void on_tbx_amount_textChanged(const QString &arg1);

    void on_tbx_installment_textChanged(const QString &arg1);

    void on_tbx_gap_per_inst_textChanged(const QString &arg1);

    void on_tbx_payment_textChanged(const QString &arg1);

    void on_ctbx_member_editTextChanged(const QString &arg1);

    void on_ctbx_member_name_editTextChanged(const QString &arg1);

private:
    Ui::form_loan *ui;
};

#endif // FORM_LOAN_H
