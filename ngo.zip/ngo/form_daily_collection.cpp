#include "form_daily_collection.h"
#include "ui_form_daily_collection.h"

form_daily_collection::form_daily_collection(QString id) :
    ui(new Ui::form_daily_collection)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);

    dbsclass dbs;
    ui->lbl_emp_id->setText(id);
    dbs.fill_label(ui->lbl_emp_name,"SELECT name FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);


    dbs.tv_display(ui->tv_customer,"select * from ngo.loan");
        dbs.fill_combobox(ui->ctbx_member_2,"SELECT * FROM ngo.member",1);

    dbs.fill_combobox(ui->ctbx_member,"SELECT * FROM ngo.member",0);


    ui->dbx_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->btn_clear->click();
}

form_daily_collection::~form_daily_collection()
{
    delete ui;
}

void form_daily_collection::on_ctbx_loan_no_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="select * from ngo.loan where id='"+arg1+"'";
    dbs.fill_tbx(ui->tbx_member,q,1);
    dbs.fill_tbx(ui->tbx_amount,q,2);
    dbs.fill_tbx(ui->tbx_interest,q,3);
    dbs.fill_tbx(ui->tbx_opening_date,q,4);
    dbs.fill_tbx(ui->tbx_duration,q,5);
    dbs.fill_tbx(ui->tbx_closing_date,q,6);
    dbs.fill_tbx(ui->tbx_return_amount,q,7);
    dbs.fill_tbx(ui->tbx_installment,q,8);
    dbs.fill_tbx(ui->tbx_gap_per_inst,q,9);
    dbs.fill_tbx(ui->tbx_payment,q,10);

    QString q2="select * from ngo.collection where loan='"+arg1+"' and date is not null";
    dbs.tv_display(ui->tv_daily_collection,"select * from ngo.collection where loan='"+arg1+"'");
    ui->tbx_colected_amount->setText(QString::number(dbs.fill_array(q2,9),'g',12));
    ui->tbx_due_amount->setText(QString::number((ui->tbx_return_amount->text().toDouble()-ui->tbx_colected_amount->text().toDouble()),'g',12));

    ui->tbx_installment_comp->setText(QString::number(dbs.tbl_sz(q2),'g',12));

    QDate r_dat=ui->dbx_date->date();
    QDate o_dat=QDate::fromString(ui->tbx_opening_date->text(),"dd/MM/yyyy");
    int dur=o_dat.daysTo(r_dat);

    ui->tbx_duration_comp->setText(QString::number(dur,'g',12));
    ui->tbx_duration_left->setText(QString::number((ui->tbx_duration->text().toDouble()-ui->tbx_duration_comp->text().toDouble()),'g',12));

    ui->tbx_inst_no->setText(QString::number(ui->tbx_installment_comp->text().toDouble()+1,'g',12));

    QDate d=QDate::fromString(ui->tbx_opening_date->text(),"dd/MM/yyyy");
    d=d.addDays(ui->tbx_gap_per_inst->text().toDouble()*ui->tbx_inst_no->text().toDouble());
    ui->dbx_installment_date->setDate(d);


     QString q3="select dayname(DATE_FORMAT(STR_TO_DATE('"+ui->tbx_opening_date->text()+"', '%d/%m/%Y'), '%Y-%m-%d'))";
     ui->tbx_day->setText(dbs.fill_string(q3,0));

     QString q4="select * from ngo.collection where loan='"+arg1+"' and installment_date='"+ui->dbx_installment_date->text()+"'";
     dbs.fill_tbx(ui->tbx_id,q4,0);

}

void form_daily_collection::on_tv_customer_clicked(const QModelIndex &index)
{
    QModelIndex indx;
    indx=ui->tv_customer->model()->index(index.row(),0,QModelIndex());
    QString id=ui->tv_customer->model()->data(indx).toString();
    ui->ctbx_loan_no->setEditText(id);
}


void form_daily_collection::on_tbx_payment_3_textChanged(const QString &arg1)
{
    ui->tbx_return->setText(QString::number((ui->tbx_due_amount->text().toDouble()-arg1.toDouble()),'g',12));
}

void form_daily_collection::on_btn_submit_clicked()
{
    /*
    int sz;

    QModelIndex index;
    dbsclass dbs;
    QString qry="INSERT INTO ngo.collection(loan, installment_no, date, collected_amount,due_amount, duration_left, mode,acc_no,payment,remarks,installment_date,day,added_by) VALUES('"+ui->ctbx_loan_no->currentText()+"','"+QString::number(ui->tbx_installment_comp->text().toDouble()+1,'g',12)+"','"+ui->dbx_date->text()+"','"+ui->tbx_colected_amount->text()+"','"+ui->tbx_due_amount->text()+"','"+ui->tbx_duration_left->text()+"','"+ui->ctbx_mode->currentText()+"','"+ui->tbx_acc_no->text()+"','"+ui->tbx_payment_3->text()+"','"+ui->tbx_remarks->text()+"','"+ui->dbx_installment_date->text()+"','"+ui->tbx_day->text()+"','"+ui->lbl_emp_id->text()+"')";


    if(ui->tbx_payment_3->text()==""||ui->ctbx_loan_no->currentText()==""){
        QMessageBox msgBox;
        msgBox.setText("Field is empty.");
        msgBox.setInformativeText("Do you want to continue?");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Ok);
        int ret = msgBox.exec();
        switch (ret) {
        case QMessageBox::Ok:
            dbs.queryfeeder(ui->tbx_id,qry);



            dbs.tv_display(ui->tv_daily_collection,"select * from ngo.collection where loan='"+ui->ctbx_loan_no->currentText()+"'");

            sz=ui->tv_daily_collection->model()->rowCount(QModelIndex());
            for(int i=0;i<sz;i++){
                index=ui->tv_daily_collection->model()->index(i,0,QModelIndex());
                if(ui->tv_daily_collection->model()->data(index).toString()==ui->tbx_id->text()){
                    ui->tv_daily_collection->selectRow(i);
                    ui->tv_daily_collection->scrollTo(index);
                }
            }
            break;

        case QMessageBox::Cancel:
            break;

        }
    }
    else{

        dbs.queryfeeder(ui->tbx_id,qry);



        dbs.tv_display(ui->tv_daily_collection,"select * from ngo.collection where loan='"+ui->ctbx_loan_no->currentText()+"'");

        sz=ui->tv_daily_collection->model()->rowCount(QModelIndex());
        for(int i=0;i<sz;i++){
            index=ui->tv_daily_collection->model()->index(i,0,QModelIndex());
            if(ui->tv_daily_collection->model()->data(index).toString()==ui->tbx_id->text()){
                ui->tv_daily_collection->selectRow(i);
                ui->tv_daily_collection->scrollTo(index);
            }
        }
    }

    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Inserted.");
    msgBox1.exec();
    //ui->btn_clear->click();*/

    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.collection set mode='"+ui->ctbx_mode->currentText()+"',acc_no='"+ui->tbx_acc_no->text()+"',payment='"+ui->tbx_payment_3->text()+"',due='"+ui->tbx_return->text()+"', remarks='"+ui->tbx_remarks->text()+"',day='"+ui->tbx_day->text()+"',installment_no='"+ui->tbx_inst_no->text()+"',date='"+ui->dbx_date->text()+"',collected_amount='"+ui->tbx_colected_amount->text()+"',due_amount='"+ui->tbx_due_amount->text()+"',duration_left='"+ui->tbx_duration_left->text()+"',added_by='"+ui->lbl_emp_id->text()+"' where loan='"+ui->ctbx_loan_no->currentText()+"' and installment_date='"+ui->dbx_installment_date->text()+"'";
    dbs.queryfeeder(q);
    dbs.tv_display(ui->tv_daily_collection,"select * from ngo.collection where loan='"+ui->ctbx_loan_no->currentText()+"'");

    sz=ui->tv_daily_collection->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_daily_collection->model()->index(i,0,QModelIndex());
        if(ui->tv_daily_collection->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_daily_collection->selectRow(i);
            ui->tv_daily_collection->scrollTo(index);
        }
    }
    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Updated.");
    msgBox1.exec();
}

void form_daily_collection::on_btn_clear_clicked()
{
    dbsclass dbs;

    ui->tbx_id->setText("Generated By System...");
    ui->ctbx_loan_no->setEditText("");
    ui->tbx_amount->setText("");
    ui->tbx_interest->setText("");
    ui->tbx_duration->setText("");
    ui->tbx_return_amount->setText("");
    ui->tbx_member->setText("");
    ui->tbx_installment->setText("");
    ui->tbx_payment->setText("");
    ui->tbx_payment->setText("");
    ui->dbx_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->tbx_opening_date->setText("");
    ui->tbx_closing_date->setText("");
    ui->tbx_duration_comp->setText("");
    ui->tbx_duration_left->setText("");
    ui->tbx_colected_amount->setText("");
    ui->tbx_due_amount->setText("");
    ui->tbx_installment_comp->setText("");
    ui->tbx_acc_no->setText("");
    ui->tbx_payment_3->setText("");
    ui->ctbx_mode->setEditText("");
    ui->tbx_return->setText("");
    ui->tbx_remarks->setText("");
    ui->tbx_gap_per_inst->setText("");
    ui->dbx_installment_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->tbx_day->setText("");

}

void form_daily_collection::on_tv_daily_collection_clicked(const QModelIndex &index)
{
    QModelIndex indx,indx1,indx2,indx3,indx4,indx5,indx6,indx0,indx12,indx13;
    indx=ui->tv_daily_collection->model()->index(index.row(),1,QModelIndex());
    QString id=ui->tv_daily_collection->model()->data(indx).toString();
    ui->ctbx_loan_no->setEditText(id);

    indx1=ui->tv_daily_collection->model()->index(index.row(),2,QModelIndex());
     QString ins=ui->tv_daily_collection->model()->data(indx1).toString();
    indx2=ui->tv_daily_collection->model()->index(index.row(),7,QModelIndex());
     QString mode=ui->tv_daily_collection->model()->data(indx2).toString();
    indx3=ui->tv_daily_collection->model()->index(index.row(),8,QModelIndex());
     QString acc=ui->tv_daily_collection->model()->data(indx3).toString();
    indx4=ui->tv_daily_collection->model()->index(index.row(),9,QModelIndex());
     QString pay=ui->tv_daily_collection->model()->data(indx4).toString();
    indx5=ui->tv_daily_collection->model()->index(index.row(),10,QModelIndex());
     QString due=ui->tv_daily_collection->model()->data(indx5).toString();
    indx6=ui->tv_daily_collection->model()->index(index.row(),11,QModelIndex());
     QString rem=ui->tv_daily_collection->model()->data(indx6).toString();
     indx0=ui->tv_daily_collection->model()->index(index.row(),0,QModelIndex());
      QString col=ui->tv_daily_collection->model()->data(indx0).toString();
      indx12=ui->tv_daily_collection->model()->index(index.row(),12,QModelIndex());
       QString i_d=ui->tv_daily_collection->model()->data(indx12).toString();
       indx13=ui->tv_daily_collection->model()->index(index.row(),3,QModelIndex());
        QString c_d=ui->tv_daily_collection->model()->data(indx13).toString();


     ui->tbx_acc_no->setText(acc);
     ui->tbx_payment_3->setText(pay);
     ui->ctbx_mode->setEditText(mode);
     ui->tbx_return->setText(due);
     ui->tbx_remarks->setText(rem);
     ui->tbx_inst_no->setText(ins);
     ui->tbx_id->setText(col);


     if(c_d!=""){
         ui->dbx_date->setDate(QDate::fromString(c_d,"dd/MM/yyyy"));
     }
     ui->dbx_installment_date->setDate(QDate::fromString(i_d,"dd/MM/yyyy"));

}


void form_daily_collection::on_btn_update_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.collection set mode='"+ui->ctbx_mode->currentText()+"',acc_no='"+ui->tbx_acc_no->text()+"',payment='"+ui->tbx_payment_3->text()+"',due='"+ui->tbx_return->text()+"', remarks='"+ui->tbx_remarks->text()+"',installment_date='"+ui->dbx_installment_date->text()+"',day='"+ui->tbx_day->text()+"' where loan='"+ui->ctbx_loan_no->currentText()+"' and installment_no='"+ui->tbx_inst_no->text()+"'";
    dbs.queryfeeder(q);
    dbs.tv_display(ui->tv_daily_collection,"select * from ngo.collection where loan='"+ui->ctbx_loan_no->currentText()+"'");

    sz=ui->tv_daily_collection->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_daily_collection->model()->index(i,0,QModelIndex());
        if(ui->tv_daily_collection->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_daily_collection->selectRow(i);
            ui->tv_daily_collection->scrollTo(index);
        }
    }
    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Updated.");
    msgBox1.exec();
    //ui->btn_clear->click();
}
void form_daily_collection::on_btn_remove_clicked()
{
    QString q="DELETE FROM ngo.collection WHERE loan='"+ui->ctbx_loan_no->currentText()+"' and installment_no='"+ui->tbx_inst_no->text()+"'";
    dbsclass dbs;
    dbs.queryfeeder(q);
    dbs.tv_display(ui->tv_daily_collection,"select * from ngo.collection where loan='"+ui->ctbx_loan_no->currentText()+"'");

    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Deleted.");
    msgBox1.exec();
}


void form_daily_collection::on_btn_cancel_clicked()
{
    form_dash *m=new form_dash(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_daily_collection::on_dbx_installment_date_dateChanged(const QDate &date)
{
    QDate o_dat=ui->dbx_date->date();
    int dur=date.daysTo(o_dat);

    ui->tbx_day_passed->setText(QString::number(dur,'g',12));
}

void form_daily_collection::on_ctbx_member_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    if(arg1=="ALL"){
        dbs.fill_combobox(ui->ctbx_loan_no,"SELECT id FROM ngo.loan",0);
    }
    else{
        dbs.fill_combobox(ui->ctbx_loan_no,"SELECT id FROM ngo.loan where member='"+arg1+"'");
        ui->ctbx_member_2->setEditText(dbs.fill_string("SELECT Name FROM ngo.member where id='"+arg1+"'",0));

    }

}


void form_daily_collection::on_ctbx_member_2_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    if(arg1=="ALL"){
        dbs.fill_combobox(ui->ctbx_member,"SELECT * FROM ngo.member",0);
    }
    else{

        ui->ctbx_member->setEditText(dbs.fill_string("SELECT id FROM ngo.member where Name='"+arg1+"'",0));
    }
}

void form_daily_collection::on_tbx_member_textChanged(const QString &arg1)
{
    QString qq="select * from ngo.member where id='"+arg1+"'";
    dbsclass dbs;
    QByteArray ba=dbs.fill_blob(qq,9);

    QPixmap pm;
    pm.loadFromData(ba);
    ui->lbl_img->setPixmap(pm);
    ui->lbl_img->setScaledContents( true );
    ui->lbl_img->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
}
