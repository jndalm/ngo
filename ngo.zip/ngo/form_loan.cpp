#include "form_loan.h"
#include "ui_form_loan.h"

form_loan::form_loan(QString id) :
    ui(new Ui::form_loan)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);

    dbsclass dbs;
    ui->lbl_emp_id->setText(id);
    dbs.fill_label(ui->lbl_emp_name,"SELECT name FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);


    dbs.tv_display(ui->tv_customer,"select * from ngo.loan");

    dbs.fill_combobox(ui->ctbx_member,"SELECT id FROM ngo.member");
    dbs.fill_combobox(ui->ctbx_member_name,"SELECT Name FROM ngo.member");
    ui->dbx_opening_date->setLocale(QLocale::English);

    ui->dbx_opening_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->dbx_opening_date->setLocale(QLocale::English);


    ui->tbx_amount->setValidator(new QRegExpValidator(QRegExp("\\b[0-9 ]{2,20}\\b")));
    ui->tbx_interest->setValidator(new QRegExpValidator(QRegExp("\\b[0-9 ]{2,20}\\b")));
    ui->tbx_duration->setValidator(new QRegExpValidator(QRegExp("\\b[0-9]{2,15}\\b")));
    ui->tbx_installment->setValidator(new QRegExpValidator(QRegExp("\\b[0-9 ]{2,20}\\b")));

    ui->btn_clear->click();
}

form_loan::~form_loan()
{
    delete ui;
}

void form_loan::on_btn_submit_clicked()
{
    int sz;

    QModelIndex index;
    dbsclass dbs;
    QString qry="INSERT INTO ngo.loan(member, amount, interest, opening_date,duration, closing_date, return_amount,installment,gap,payment,benefit,day,remarks,added_by) VALUES('"+ui->ctbx_member->currentText()+"','"+ui->tbx_amount->text()+"','"+ui->tbx_interest->text()+"','"+ui->dbx_opening_date->text()+"','"+ui->tbx_duration->text()+"','"+ui->dbx_closing_date->text()+"','"+ui->tbx_return_amount->text()+"','"+ui->tbx_installment->text()+"','"+ui->tbx_gap_per_inst->text()+"','"+ui->tbx_payment->text()+"','"+ui->tbx_benefit->text()+"','"+ui->tbx_day->text()+"','"+ui->tbx_remarks->text()+"','"+ui->lbl_emp_id->text()+"')";


    if(ui->ctbx_member->currentText()==""||ui->tbx_amount->text()==""||ui->tbx_interest->text()==""||ui->tbx_duration->text()==""||ui->tbx_installment->text()==""){
        QMessageBox msgBox;
        msgBox.setText("Field is empty.");
        msgBox.setInformativeText("Do you want to continue?");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Ok);
        int ret = msgBox.exec();
        switch (ret) {
        case QMessageBox::Ok:
            dbs.queryfeeder(ui->tbx_id,qry);



            dbs.tv_display(ui->tv_customer,"select * from ngo.loan");

            sz=ui->tv_customer->model()->rowCount(QModelIndex());
            for(int i=0;i<sz;i++){
                index=ui->tv_customer->model()->index(i,0,QModelIndex());
                if(ui->tv_customer->model()->data(index).toString()==ui->tbx_id->text()){
                    ui->tv_customer->selectRow(i);
                    ui->tv_customer->scrollTo(index);
                }
            }
            break;

        case QMessageBox::Cancel:
            break;

        }
    }
    else{

        dbs.queryfeeder(ui->tbx_id,qry);



        dbs.tv_display(ui->tv_customer,"select * from ngo.loan");

        sz=ui->tv_customer->model()->rowCount(QModelIndex());
        for(int i=0;i<sz;i++){
            index=ui->tv_customer->model()->index(i,0,QModelIndex());
            if(ui->tv_customer->model()->data(index).toString()==ui->tbx_id->text()){
                ui->tv_customer->selectRow(i);
                ui->tv_customer->scrollTo(index);
            }
        }
    }

    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Inserted.");
    msgBox1.exec();

    int dur=ui->tbx_duration->text().toDouble()/ui->tbx_gap_per_inst->text().toDouble();
    QDate dat=QDate::fromString(ui->dbx_opening_date->text(),"dd/MM/yyyy"),t_d;
    QString qry2,d;
    for(int i=0;i<dur;i++){
        t_d=dat.addDays(ui->tbx_gap_per_inst->text().toDouble()*(i+1));
        d=t_d.toString("dd/MM/yyyy");
        qry2="INSERT INTO ngo.collection(loan,installment_no,installment_date) VALUES('"+ui->tbx_id->text()+"','"+QString::number(i+1)+"','"+d+"')";
        dbs.queryfeeder(qry2);
    }

   // QString qry="INSERT INTO ngo.collection(loa,installment_date) VALUES('"+ui->tbx_id->text()+"','"+ui->dbx_installment_date->text()+"','"+ui->tbx_day->text()+"','"+ui->lbl_emp_id->text()+"')";


    ui->btn_clear->click();

}

void form_loan::on_btn_update_clicked()
{
    int sz;
    QModelIndex index;
    dbsclass dbs;
    QString q="update ngo.loan set member='"+ui->ctbx_member->currentText()+"',amount='"+ui->tbx_amount->text()+"',interest='"+ui->tbx_interest->text()+"',opening_date='"+ui->dbx_opening_date->text()+"', duration='"+ui->tbx_duration->text()+"',  closing_date='"+ui->dbx_closing_date->text()+"', return_amount='"+ui->tbx_return_amount->text()+"', installment='"+ui->tbx_installment->text()+"',gap='"+ui->tbx_gap_per_inst->text()+"', payment='"+ui->tbx_payment->text()+"', benefit='"+ui->tbx_benefit->text()+"', day='"+ui->tbx_day->text()+"', remarks='"+ui->tbx_remarks->text()+"' where id='"+ui->tbx_id->text()+"'";
    dbs.queryfeeder(q);
    dbs.tv_display(ui->tv_customer,"select * from ngo.loan");

    sz=ui->tv_customer->model()->rowCount(QModelIndex());
    for(int i=0;i<sz;i++){
        index=ui->tv_customer->model()->index(i,0,QModelIndex());
        if(ui->tv_customer->model()->data(index).toString()==ui->tbx_id->text()){
            ui->tv_customer->selectRow(i);
            ui->tv_customer->scrollTo(index);
        }
    }
    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Updated.");
    msgBox1.exec();
    ui->btn_clear->click();
}

void form_loan::on_btn_remove_clicked()
{
    QString q="DELETE FROM ngo.loan WHERE id='"+ui->tbx_id->text()+"'";
    dbsclass dbs;
    dbs.queryfeeder(q);
    dbs.tv_display(ui->tv_customer,"select * from ngo.loan");

    QMessageBox msgBox1;
    msgBox1.setText("Data Successfully Deleted.");
    msgBox1.exec();
    ui->btn_clear->click();
}

void form_loan::on_btn_cancel_clicked()
{
    form_dash *m=new form_dash(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_loan::on_tv_customer_clicked(const QModelIndex &index)
{
    QModelIndex indx,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11;

    indx=ui->tv_customer->model()->index(index.row(),0,QModelIndex());
    index2=ui->tv_customer->model()->index(index.row(),2,QModelIndex());
    index3=ui->tv_customer->model()->index(index.row(),3,QModelIndex());
    index4=ui->tv_customer->model()->index(index.row(),4,QModelIndex());
    index5=ui->tv_customer->model()->index(index.row(),5,QModelIndex());
    index6=ui->tv_customer->model()->index(index.row(),6,QModelIndex());
    index7=ui->tv_customer->model()->index(index.row(),7,QModelIndex());
    index8=ui->tv_customer->model()->index(index.row(),8,QModelIndex());
    index9=ui->tv_customer->model()->index(index.row(),9,QModelIndex());
    index11=ui->tv_customer->model()->index(index.row(),1,QModelIndex());
    index10=ui->tv_customer->model()->index(index.row(),10,QModelIndex());

    QString id=ui->tv_customer->model()->data(indx).toString();
    QString mem=ui->tv_customer->model()->data(index11).toString();
    QString amo=ui->tv_customer->model()->data(index2).toString();
    QString interest=ui->tv_customer->model()->data(index3).toString();
    QString o_date=ui->tv_customer->model()->data(index4).toString();
    QString dur=ui->tv_customer->model()->data(index5).toString();
    QString c_date=ui->tv_customer->model()->data(index6).toString();
    QString ret=ui->tv_customer->model()->data(index7).toString();
    QString ins=ui->tv_customer->model()->data(index8).toString();

    QString pay=ui->tv_customer->model()->data(index10).toString();
    QString gap=ui->tv_customer->model()->data(index9).toString();

    ui->tbx_id->setText(id);
    ui->tbx_amount->setText(amo);
    ui->tbx_interest->setText(interest);
    ui->tbx_duration->setText(dur);


    ui->tbx_return_amount->setText(ret);
    ui->ctbx_member->setEditText(mem);
    ui->tbx_installment->setText(ins);
    ui->tbx_gap_per_inst->setText(gap);
    ui->tbx_payment->setText(pay);
    ui->dbx_opening_date->setLocale(QLocale::English);
    QDate dat=QDate::fromString(o_date,"dd/MM/yyyy");
    QDate c_dat=QDate::fromString(c_date,"dd/MM/yyyy");

    ui->dbx_opening_date->setDate(dat);
    ui->dbx_closing_date->setDate(c_dat);
}

void form_loan::on_btn_clear_clicked()
{
    dbsclass dbs;

    ui->tbx_id->setText("Generated By System...");
    ui->tbx_amount->setText("");
    ui->tbx_interest->setText("");

    ui->tbx_return_amount->setText("");
    ui->ctbx_member->setEditText("");

    ui->tbx_payment->setText("");
    ui->dbx_opening_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->dbx_closing_date->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));
    ui->tbx_installment->setText("");
    ui->tbx_gap_per_inst->setText("");
    ui->tbx_benefit->setText("");
    ui->tbx_duration->setText("");
}

void form_loan::on_tbx_search_textChanged(const QString &arg1)
{
    dbsclass dbs;
    dbs.search_tv(arg1,ui->tv_customer);
}

void form_loan::on_btn_export_customer_csv_clicked()
{
    dbsclass dbs;
    dbs.csv_exp("Loan Details",ui->tv_customer);
}

void form_loan::on_tbx_interest_textChanged(const QString &arg1)
{
    double amo=ui->tbx_amount->text().toDouble(),interst=arg1.toDouble();
    double ret_val=amo+((amo*interst)/100);
    ui->tbx_return_amount->setText(QString::number(ret_val,'g',12));

    ui->tbx_benefit->setText(QString::number(ui->tbx_return_amount->text().toDouble()-ui->tbx_amount->text().toDouble(),'g',12));
}

void form_loan::on_tbx_duration_textChanged(const QString &arg1)
{
    QDate d=QDate::fromString(ui->dbx_opening_date->text(),"dd/MM/yyyy");
    d=d.addDays(arg1.toDouble());
    ui->dbx_closing_date->setDate(d);
}

void form_loan::on_dbx_closing_date_dateChanged(const QDate &date)
{

    QDate o_dat=ui->dbx_opening_date->date();
    int dur=o_dat.daysTo(date);

    ui->tbx_duration->setText(QString::number(dur,'g',12));
}

void form_loan::on_dbx_opening_date_dateChanged(const QDate &date)
{
    QString x=ui->tbx_duration->text();
    ui->tbx_duration->setText("");
    ui->tbx_duration->setText(x);

    QDate o_dat=ui->dbx_opening_date->date();
    ui->tbx_day->setLocale(QLocale::English);
    ui->tbx_day->setText(o_dat.toString("dddd"));
    //ui->tbx_remarks->setText(o_dat.toString("dddd"));

   dbsclass dbs;
    QString q="select dayname(DATE_FORMAT(STR_TO_DATE('"+ui->dbx_opening_date->text()+"', '%d/%m/%Y'), '%Y-%m-%d'))";
    ui->tbx_day->setText(dbs.fill_string(q,0));
}

void form_loan::on_tbx_amount_textChanged(const QString &arg1)
{
    QString x=ui->tbx_interest->text();
    ui->tbx_interest->setText("");
    ui->tbx_interest->setText(x);
}

void form_loan::on_tbx_installment_textChanged(const QString &arg1)
{
    int x=ui->tbx_duration->text().toDouble()/arg1.toDouble();
    double y=ui->tbx_return_amount->text().toDouble()/arg1.toDouble();

    //ui->tbx_gap_per_inst->setText(QString::number(x,'g',12));
  //  ui->tbx_payment->setText(QString::number(y,'g',12));

}

void form_loan::on_tbx_gap_per_inst_textChanged(const QString &arg1)
{
    int x=arg1.toDouble();
    double y=ui->tbx_return_amount->text().toDouble()/ui->tbx_payment->text().toDouble();

   // ui->tbx_installment->setText(QString::number(x,'g',12));
    ui->tbx_duration->setText(QString::number(y*x,'g',12));
}

void form_loan::on_tbx_payment_textChanged(const QString &arg1)
{
    int x=ui->tbx_return_amount->text().toDouble()/arg1.toDouble();
   // int y=ui->tbx_return_amount->text().toDouble()/x;

    ui->tbx_installment->setText(QString::number(x,'g',12));
   // ui->tbx_payment->setText(QString::number(y,'g',12));
}

void form_loan::on_ctbx_member_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="SELECT * FROM ngo.member where id='"+arg1+"'";
    ui->ctbx_member_name->setEditText(dbs.fill_string(q,1));
    QByteArray ba=dbs.fill_blob(q,9);

    QPixmap pm;
    pm.loadFromData(ba);
    ui->lbl_img->setPixmap(pm);
    ui->lbl_img->setScaledContents( true );
    ui->lbl_img->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
}

void form_loan::on_ctbx_member_name_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="SELECT * FROM ngo.member where Name='"+arg1+"'";
    ui->ctbx_member->setEditText(dbs.fill_string(q,0));
}
