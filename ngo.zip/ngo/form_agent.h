#ifndef FORM_AGENT_H
#define FORM_AGENT_H

#include <QWidget>
#include <QDesktopWidget>
#include<QMessageBox>
#include<dbsclass.h>
#include<form_dash.h>

namespace Ui {
class form_agent;
}

class form_agent : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_agent(QString id);
    ~form_agent();

    QByteArray ba;
    
private slots:
    void on_btn_submit_clicked();

    void on_btn_cancel_clicked();

    void on_tv_customer_clicked(const QModelIndex &index);

    void on_tbx_search_textChanged(const QString &arg1);

    void on_btn_submit_2_clicked();

    void on_btn_remove_clicked();

    void on_btn_cancel_2_clicked();

    void on_btn_export_customer_csv_clicked();



    void on_ctbx_type_editTextChanged(const QString &arg1);

    void on_btn_clear_clicked();

    void on_btn_upload_image_clicked();

private:
    Ui::form_agent *ui;
};

#endif // FORM_AGENT_H
