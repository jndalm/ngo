#include "login.h"
#include "ui_login.h"
#include<form_dash.h>

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    //bring window to center
    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);

    ui->grp_server->setHidden(true);

    //validation
    ui->tbx_db_name->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9]{2,60}\\b")));
    ui->tbx_db_user->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9]{2,60}\\b")));
    ui->tbx_host->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9 .]{2,60}\\b")));
    ui->tbx_id->setValidator(new QRegExpValidator(QRegExp("\\b[A-Za-z0-9]{2,60}\\b")));
    ui->tbx_port->setValidator(new QRegExpValidator(QRegExp("\\b[0-9]{2,60}\\b")));
}

login::~login()
{
    delete ui;
    QApplication::quit();
}

void login::on_btn_login_clicked()
{
    QFile file("server_conn.txt");
    if (!file.open(QFile::ReadOnly | QFile::Text)){}
    QTextStream in(&file);
    QString temp = in.readAll();
    QStringList lst=temp.split(",");
    file.close();

    dbsclass dbs;
    dbs.conn(lst);

    bool b=dbs.chkpass("SELECT * FROM ngo.employee where id='"+ui->tbx_id->text()+"' and password='"+ui->tbx_pass->text()+"'");
    bool b1=dbs.chkpass("SELECT * FROM ngo.employee where name='"+ui->tbx_id->text()+"' and password='"+ui->tbx_pass->text()+"'");
    QString q="SELECT * FROM ngo.employee where name='"+ui->tbx_id->text()+"' and password='"+ui->tbx_pass->text()+"'";

    if(b==true){
        form_dash *d=new form_dash(ui->tbx_id->text());
        d->show();

        this->hide();
    }
    else if(b1==true){
        form_dash *d=new form_dash(dbs.fill_string(q,0));
        d->show();
        this->hide();

    }
    else{
        QMessageBox m;
        m.setText("Wrong Id or Password!!!!!");
        m.exec();
    }
}
void login::keyPressEvent(QKeyEvent *ev){
    if(ev->modifiers().testFlag(Qt::ControlModifier)){
        if(ev->modifiers().testFlag(Qt::ShiftModifier)){
            if(ev->key()==Qt::Key_B){
                QFile file("server_conn.txt");
                if (!file.open(QFile::ReadOnly | QFile::Text)){}
                QTextStream in(&file);
                QString temp = in.readAll();
                QStringList lst=temp.split(",");
                file.close();



                dbsclass dbs;
                dbs.conn(lst);

                form_employee *d=new form_employee(ui->tbx_id->text());
                d->show();

                this->hide();
            }
        }
        else if(ev->key()==Qt::Key_S){
            ui->grp_server->move(ui->label->pos().x(),ui->label->pos().y());
            ui->grp_server->setHidden(false);

            QFile file("server_conn.txt");
            if (!file.open(QFile::ReadOnly | QFile::Text)){}
            QTextStream in(&file);
            QString temp = in.readAll();
            QStringList lst=temp.split(",");
            file.close();

            ui->tbx_host->setText(lst.value(0));
            ui->tbx_db_name->setText(lst.value(1));
            ui->tbx_db_user->setText(lst.value(2));
            ui->tbx_db_pass->setText(lst.value(3));
            ui->tbx_port->setText(lst.value(4));
            ui->tbx_host->setFocus();
        }
    }
    if(ev->key()==Qt::Key_Escape){
        ui->grp_server->setHidden(true);
    }
}

void login::on_tbx_id_returnPressed()
{
    ui->btn_login->click();
}

void login::on_tbx_pass_returnPressed()
{
    ui->btn_login->click();
}

void login::on_btn_cancel_clicked()
{
    QApplication::quit();
}

void login::on_tbx_host_returnPressed()
{
    ui->btn_setup->click();
}

void login::on_tbx_port_returnPressed()
{
    ui->btn_setup->click();
}

void login::on_tbx_db_name_returnPressed()
{
    ui->btn_setup->click();
}

void login::on_tbx_db_user_returnPressed()
{
    ui->btn_setup->click();
}

void login::on_tbx_db_pass_returnPressed()
{
    ui->btn_setup->click();
}

void login::on_btn_setup_clicked()
{
    QString repl=ui->tbx_host->text()+","+ui->tbx_db_name->text()+","+ui->tbx_db_user->text()+","+ui->tbx_db_pass->text()+","+ui->tbx_port->text();

    QFile file("server_conn.txt");
    if (!file.open(QFile::ReadWrite | QFile::Text)){}
    file.seek(0);
    file.write(repl.toUtf8());
    file.close();
}

void login::on_btn_hide_clicked()
{
    ui->grp_server->setHidden(true);
}
