#include "form_visualization.h"
#include "ui_form_visualization.h"

form_visualization::form_visualization(QString id) :
    ui(new Ui::form_visualization)
{
    ui->setupUi(this);

    QPixmap bkgnd(":/new/prefix1/images/v.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    QRect desktopRect = QApplication::desktop()->availableGeometry(this);
    QPoint center = desktopRect.center();
    move(center.x()-width()*0.5, center.y()-height()*0.5);

    dbsclass dbs;
    ui->lbl_emp_id->setText(id);
    dbs.fill_label(ui->lbl_emp_name,"SELECT name FROM ngo.employee where id='"+ui->lbl_emp_id->text()+"'",0);

    QString q="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name, DATE_FORMAT(now(), '%Y-%m-%d') as Today,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed FROM ngo.loan where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))+0)%gap+0=0";
    //dbs.tv_display(ui->tv_todays_collection,q);

    QString q2="SELECT member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT joining_date FROM ngo.member where id=loan.member) as Joining_date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT joining_date FROM ngo.member where id=loan.member), '%d.%m.%Y'), '%Y-%m-%d')) as Working_Duration,count(id) as Loan_Count,sum(installment) as Total_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Completed_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0) as Ondate_Installment,((((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0)+0)*100)/((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))))+0) as Percentage,sum(amount) as Amount,sum(return_amount) as Return_Amount,(SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Collected_amount,(sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) as Due_Amount,((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0)) as Collected_Capital,(((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)-(((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0))+0)) as Collected_Benefit FROM ngo.loan group by member order by (sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)";
    dbs.tv_display(ui->tv_rev_member,q2);
    ui->tv_rev_member->resizeColumnsToContents();
    ui->lbl_emp_name->setText(QString::number(q2.length()));

    dbs.generate_singel_graph(ui->plot_rev_member,q2,0,7,"Member Id","On date Collection(%)","Percentage");



    ui->ctbx_rev_type->setEditText("");
    ui->ctbx_rev_type->setEditText("Incomplete");
    //---------------------------------------------------------------------------------------------------------------------------------------------------------
    ui->tbx_end_date_inv->setDate(QDate::fromString(dbs.recent_date(),"yyyy-MM-dd"));

    QString q4="select id from ngo.loan";
    dbs.fill_combobox(ui->ctnx_loan,q4);

    QString q5="select id from ngo.member";
    dbs.fill_combobox(ui->ctbx_member,q5);

    QString q6="select Name from ngo.member";
    dbs.fill_combobox(ui->ctbx_member_name,q6);

    ui->btn_pie_rev_member->click();


    QString temp=ui->ctbx_ext_duration_type->currentText();
    ui->ctbx_ext_duration_type->setEditText("");
    ui->ctbx_ext_duration_type->setEditText(temp);

    QString temp2=ui->ctbx_member_3->currentText();
    ui->ctbx_member_3->setEditText("");
    ui->ctbx_member_3->setEditText(temp2);

}

form_visualization::~form_visualization()
{
    delete ui;
}

void form_visualization::on_ctbx_member_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="SELECT * FROM ngo.member where id='"+arg1+"'";
    ui->ctbx_member_name->setEditText(dbs.fill_string(q,1));
    dbs.tv_display(ui->tv_member_info,q);
    ui->tv_member_info->resizeColumnsToContents();


    QByteArray ba=dbs.fill_blob(q,9);

    QPixmap pm;
    pm.loadFromData(ba);
    ui->lbl_img->setPixmap(pm);
    ui->lbl_img->setScaledContents( true );
    ui->lbl_img->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );

    QString q1="SELECT * FROM ngo.loan where member='"+arg1+"'";
    dbs.tv_display(ui->tv_member_loan,q1);
    ui->tv_member_loan->resizeColumnsToContents();

    QString q2="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and member='"+arg1+"'";

    dbs.tv_display(ui->tv_member_coollection,q2);
    ui->tv_member_coollection->resizeColumnsToContents();

    ui->tbx_loan_amount_2->setText(QString::number(dbs.fill_array(q2,6),'g',12));
    ui->tbx_ret_amo_2->setText(QString::number(dbs.fill_array(q2,8),'g',12));
    ui->tbx_col_amo_2->setText(QString::number(dbs.fill_array(q2,10),'g',12));
    ui->tbx_col_capital_2->setText(QString::number(dbs.fill_array(q2,13),'g',12));
    ui->tbx_totlbene_2->setText(QString::number(dbs.fill_array(q2,9),'g',12));
    ui->tbx_col_bene_2->setText(QString::number(dbs.fill_array(q2,12),'g',12));

    ui->tbx_due_amo_2->setText(QString::number(ui->tbx_ret_amo_2->text().toDouble()-ui->tbx_col_amo_2->text().toDouble()));
    ui->tbx_due_capital_2->setText(QString::number(ui->tbx_loan_amount_2->text().toDouble()-ui->tbx_col_capital_2->text().toDouble()));
    ui->tbx_due_bene_2->setText(QString::number(ui->tbx_totlbene_2->text().toDouble()-ui->tbx_col_bene_2->text().toDouble()));

    ui->btn_pie_member->click();
}

void form_visualization::on_btn_cancel_clicked()
{
    form_dash *m=new form_dash(ui->lbl_emp_id->text());
    m->show();
    m->setAttribute(Qt::WA_DeleteOnClose);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->hide();
    this->close();
    delete this;
}

void form_visualization::on_ctbx_rev_type_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q2,q3;
    if(arg1=="All"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage  FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    else if(arg1=="Complete"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage  FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0>=return_amount+0 and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0>=return_amount+0 and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }

    else if(arg1=="Incomplete"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0<return_amount+0 or (select sum(payment) as ss from ngo.collection where loan=loan.id) is null and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0<return_amount+0 or (select sum(payment) as ss from ngo.collection where loan=loan.id) is null and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    else{
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }

    dbs.tv_display(ui->tv_busnessStatus,q2);
    ui->tv_busnessStatus->resizeColumnsToContents();ui->tbx_loan_amount->setText(QString::number(dbs.fill_array(q2,7),'g',12));
    ui->tbx_ret_amo->setText(QString::number(dbs.fill_array(q2,9),'g',12));
    ui->tbx_col_amo->setText(QString::number(dbs.fill_array(q2,11),'g',12));
    ui->tbx_col_capital->setText(QString::number(dbs.fill_array(q2,14),'g',12));
    ui->tbx_totlbene->setText(QString::number(dbs.fill_array(q2,10),'g',12));
    ui->tbx_col_bene->setText(QString::number(dbs.fill_array(q2,13),'g',12));

    ui->tbx_due_amo->setText(QString::number(ui->tbx_ret_amo->text().toDouble()-ui->tbx_col_amo->text().toDouble()));
    ui->tbx_due_capital->setText(QString::number(ui->tbx_loan_amount->text().toDouble()-ui->tbx_col_capital->text().toDouble()));
    ui->tbx_due_bene->setText(QString::number(ui->tbx_totlbene->text().toDouble()-ui->tbx_col_bene->text().toDouble()));


    for(int i=0;i<dbs.tbl_sz(q2);i++){
        QProgressBar *prog=new QProgressBar();
        QModelIndex in=ui->tv_busnessStatus->model()->index(i,15,QModelIndex());
        QString val=ui->tv_busnessStatus->model()->data(in).toString();
        QModelIndex in2=ui->tv_busnessStatus->model()->index(i,2,QModelIndex());
        prog->setValue(val.toDouble());
        prog->setTextVisible(true);
        ui->tv_busnessStatus->setIndexWidget(in2,prog);
    }
    dbs.generate_singel_graph(ui->plot_rev,q3,0,14,"Loan_Id","Completed(%)","Percentage");

    ui->btn_pie_rev_loan->click();
}

void form_visualization::on_ctbx_ext_duration_type_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="select date as Date,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by date";
    dbs.tv_display(ui->tv_ext_datewise,q);
    ui->tv_ext_datewise->resizeColumnsToContents();

    if(arg1=="Year"){
        q="select year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Year,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) order by year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc";
        dbs.tv_display(ui->tv_ext_datewise,q);
        ui->tv_ext_datewise->resizeColumnsToContents();
        dbs.generate_singel_graph(ui->plot_month,q,0,2,"Year","Benefit","Benefit");

    }
    else if(arg1=="Month"){
        q="select year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Year,monthname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Month,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by monthname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')),year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) order by month(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc,year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc";
        dbs.tv_display(ui->tv_ext_datewise,q);
        ui->tv_ext_datewise->resizeColumnsToContents();
        dbs.generate_singel_graph(ui->plot_month,q,1,3,"Month","Benefit","Benefit");
    }
    else if(arg1=="Week"){
        q="select year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Year,monthname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Month,week(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Week,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by week(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')),monthname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')),year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) order by week(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc, month(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc,year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc";
        dbs.tv_display(ui->tv_ext_datewise,q);
        ui->tv_ext_datewise->resizeColumnsToContents();
        dbs.generate_singel_graph(ui->plot_month,q,2,4,"Week","Benefit","Benefit");
    }
    else if(arg1=="Date"){
        q="select year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Year,monthname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Month,week(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Week,date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Date,dayname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) as Day,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')),week(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')),monthname(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')),year(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) order by date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) desc";
        dbs.tv_display(ui->tv_ext_datewise,q);
        ui->tv_ext_datewise->resizeColumnsToContents();
        dbs.generate_singel_graph(ui->plot_month,q,3,5,"Date","Benefit","Benefit");
    }
    else if(arg1=="Day"){
        q="select day as Day,sum(payment+0) as Collected_Amount,sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100) as Collected_Benefit, (sum(payment+0)-sum(((payment+0)*(SELECT interest FROM ngo.loan where id=collection.loan)+0)/100)) as Collected_Capital from ngo.collection group by day";
        dbs.tv_display(ui->tv_ext_datewise,q);
        ui->tv_ext_datewise->resizeColumnsToContents();
        dbs.generate_singel_graph(ui->plot_month,q,0,2,"Year","Benefit","Benefit");
    }
}

void form_visualization::on_ctnx_loan_editTextChanged(const QString &arg1)
{
    ///----------------------------------------------------------------------------------------
    dbsclass dbs;
    // QString q2="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where id='"+arg1+"' and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    QString q3="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where id='"+arg1+"' and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";

    dbs.tv_display(ui->tv_loan,q3);
    ui->tv_loan->resizeColumnsToContents();
    dbs.fill_tbx(ui->tbx_member_loan,q3,1);

    QString q="select * from ngo.collection where loan='"+arg1+"' and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    dbs.tv_display(ui->tv_loan_daily_collection,q);
    ui->tv_loan_daily_collection->resizeColumnsToContents();

    for(int i=0;i<dbs.tbl_sz(q3);i++){
        QProgressBar *prog=new QProgressBar();
        QModelIndex in=ui->tv_loan->model()->index(i,15,QModelIndex());
        QString val=ui->tv_loan->model()->data(in).toString();
        QModelIndex in2=ui->tv_loan->model()->index(i,2,QModelIndex());
        prog->setValue(val.toDouble());
        prog->setTextVisible(true);
        ui->tv_loan->setIndexWidget(in2,prog);
    }


    ui->prg_loan_details->setValue(dbs.fill_string(q3,15).toDouble());
    ui->rnd_loan_details->setValue(dbs.fill_string(q3,15).toDouble());
    dbs.generate_singel_graph(ui->plot_loan_installment,q,12,9,"Installment Date","Collection","Amount");

    ui->btn_pie_loan_details->click();

}

void form_visualization::on_ctbx_member_3_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
    dbs.tv_display(ui->tv_ext_missdate,q);
    ui->tv_ext_datewise->resizeColumnsToContents();

    if(arg1=="On Date Collection"){
        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
        dbs.tv_display(ui->tv_ext_missdate,q);
        ui->tv_ext_missdate->resizeColumnsToContents();
    }
    else if(arg1=="Miss Date Collection"){
        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
        dbs.tv_display(ui->tv_ext_missdate,q);
        ui->tv_ext_missdate->resizeColumnsToContents();
    }
    else if(arg1=="Empty Collection"){
        q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null order by loan";
        dbs.tv_display(ui->tv_ext_missdate,q);
        ui->tv_ext_missdate->resizeColumnsToContents();
    }
}

void form_visualization::on_ctbx_member_name_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="SELECT * FROM ngo.member where Name='"+arg1+"'";
    ui->ctbx_member->setEditText(dbs.fill_string(q,0));
}

void form_visualization::on_tv_rev_member_doubleClicked(const QModelIndex &index)
{
    ui->tabWidget->setCurrentIndex(1);
    QModelIndex indx;

    indx=ui->tv_rev_member->model()->index(index.row(),0,QModelIndex());
    QString b=ui->tv_rev_member->model()->data(indx).toString();
    ui->tab_revinue->clearFocus();
    ui->tab_member->setFocus();
    ui->ctbx_member->setEditText(b);
}

void form_visualization::on_tv_busnessStatus_doubleClicked(const QModelIndex &index)
{
    ui->tabWidget->setCurrentIndex(2);
    QModelIndex indx;

    indx=ui->tv_busnessStatus->model()->index(index.row(),0,QModelIndex());
    QString b=ui->tv_busnessStatus->model()->data(indx).toString();
    ui->tab_revinue->clearFocus();
    ui->tab_loan->setFocus();
    ui->ctnx_loan->setEditText(b);
}

void form_visualization::on_tv_loan_doubleClicked(const QModelIndex &index)
{
    ui->tabWidget->setCurrentIndex(1);
    QModelIndex indx;

    indx=ui->tv_loan->model()->index(index.row(),1,QModelIndex());
    QString b=ui->tv_loan->model()->data(indx).toString();
    ui->tab_loan->clearFocus();
    ui->tab_member->setFocus();
    ui->ctbx_member->setEditText(b);
}

void form_visualization::on_tv_member_loan_doubleClicked(const QModelIndex &index)
{
    ui->tabWidget->setCurrentIndex(2);
    QModelIndex indx;

    indx=ui->tv_member_loan->model()->index(index.row(),0,QModelIndex());
    QString b=ui->tv_member_loan->model()->data(indx).toString();
    ui->tab_member->clearFocus();
    ui->tab_loan->setFocus();
    ui->ctnx_loan->setEditText(b);
}

void form_visualization::on_tv_ext_missdate_doubleClicked(const QModelIndex &index)
{
    ui->tabWidget->setCurrentIndex(2);
    QModelIndex indx;

    indx=ui->tv_ext_missdate->model()->index(index.row(),0,QModelIndex());
    QString b=ui->tv_ext_missdate->model()->data(indx).toString();
    ui->tab_extensions->clearFocus();
    ui->tab_loan->setFocus();
    ui->ctnx_loan->setEditText(b);
}

void form_visualization::on_btn_pie_member_clicked()
{
    dbsclass dbs;
    QString q2="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and member='"+ui->ctbx_member->currentText()+"'";

    if(ui->ctbx_member_pie_type->currentText()=="Due"){
        double ttl=dbs.fill_array(q2,11),f;
        QString val="",t;
        QString val1=dbs.fill_array_string(q2,11);
        QStringList v=val1.split(",");
        for(int i=0;i<dbs.tbl_sz(q2);i++){
            t=v.value(i);
            f=(t.toDouble()*100)/ttl;

            if(i==0){
                val+=QString::number(f,'g',12);
            }
            else{
                val+=",";
                val+=QString::number(f,'g',12);
            }
        }
        QString nam=dbs.fill_array_string(q2,0);
        dbs.pie3d(ui->lbl_plot_member,nam,val);
        //dbs.bargraph3d(ui->lbl_bar_chart_,nam,val);
    }

    else if(ui->ctbx_member_pie_type->currentText()=="Benefit"){
        double ttl=dbs.fill_array(q2,12),f;
        QString val="",t;
        QString val1=dbs.fill_array_string(q2,12);
        QStringList v=val1.split(",");
        for(int i=0;i<dbs.tbl_sz(q2);i++){
            t=v.value(i);
            f=(t.toDouble()*100)/ttl;

            if(i==0){
                val+=QString::number(f,'g',12);
            }
            else{
                val+=",";
                val+=QString::number(f,'g',12);
            }
        }
        QString nam=dbs.fill_array_string(q2,0);
        dbs.pie3d(ui->lbl_plot_member,nam,val);
        //dbs.bargraph3d(ui->lbl_bar_chart_,nam,val);
    }
    else if(ui->ctbx_member_pie_type->currentText()=="Collection"){
        QString q;

        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
        int on_date=dbs.tbl_sz(q);

        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
        int miss_date=dbs.tbl_sz(q);

        q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' and payment is null order by loan";
        int emp_date=dbs.tbl_sz(q);

        double tl=on_date+miss_date+emp_date;

        double f=(on_date*100)/tl;
        QString val=QString::number(f,'g',12);

        f=(miss_date*100)/tl;
        val+=","+QString::number(f,'g',12);

        f=(emp_date*100)/tl;
        val+=","+QString::number(f,'g',12);

        val+=",0";

        QString name="On Date Collection,Miss Date Collection,Empty Collection,o";
        dbs.pie3d(ui->lbl_plot_member,name,val);
    }
    //************************************************************************************************
}

void form_visualization::on_btn_bar_member_clicked()
{
    dbsclass dbs;
    QString q2="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and member='"+ui->ctbx_member->currentText()+"'";

    if(ui->ctbx_member_pie_type->currentText()=="Due"){
        double ttl=dbs.fill_array(q2,11),f;
        QString val="",t;
        QString val1=dbs.fill_array_string(q2,11);
        QStringList v=val1.split(",");
        for(int i=0;i<dbs.tbl_sz(q2);i++){
            t=v.value(i);
            f=(t.toDouble()*100)/ttl;

            if(i==0){
                val+=QString::number(f,'g',12);
            }
            else{
                val+=",";
                val+=QString::number(f,'g',12);
            }
        }
        QString nam=dbs.fill_array_string(q2,0);
        //dbs.pie3d(ui->lbl_plot_member,nam,val);
        dbs.bargraph3d(ui->lbl_plot_member,nam,val);
    }

    else if(ui->ctbx_member_pie_type->currentText()=="Benefit"){
        double ttl=dbs.fill_array(q2,12),f;
        QString val="",t;
        QString val1=dbs.fill_array_string(q2,12);
        QStringList v=val1.split(",");
        for(int i=0;i<dbs.tbl_sz(q2);i++){
            t=v.value(i);
            f=(t.toDouble()*100)/ttl;

            if(i==0){
                val+=QString::number(f,'g',12);
            }
            else{
                val+=",";
                val+=QString::number(f,'g',12);
            }
        }
        QString nam=dbs.fill_array_string(q2,0);
        //dbs.pie3d(ui->lbl_plot_member,nam,val);
        dbs.bargraph3d(ui->lbl_plot_member,nam,val);
    }
    else if(ui->ctbx_member_pie_type->currentText()=="Collection"){
        QString q;

        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
        int on_date=dbs.tbl_sz(q);

        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
        int miss_date=dbs.tbl_sz(q);

        q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' and payment is null order by loan";
        int emp_date=dbs.tbl_sz(q);

        double tl=on_date+miss_date+emp_date;

        double f=(on_date*100)/tl;
        QString val=QString::number(f,'g',12);

        f=(miss_date*100)/tl;
        val+=","+QString::number(f,'g',12);

        f=(emp_date*100)/tl;
        val+=","+QString::number(f,'g',12);

        val+=",0";

        QString name="On Date Collection,Miss Date Collection,Empty Collection,o";
        dbs.bargraph3d(ui->lbl_plot_member,name,val);
    }
}

void form_visualization::on_btn_pie_rev_loan_clicked()
{
    dbsclass dbs;
    QString q2,q3;
    if(ui->ctbx_rev_type->currentText()=="All"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage  FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    else if(ui->ctbx_rev_type->currentText()=="Complete"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage  FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0>=return_amount+0 and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0>=return_amount+0 and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }

    else if(ui->ctbx_rev_type->currentText()=="Incomplete"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0<return_amount+0 or (select sum(payment) as ss from ngo.collection where loan=loan.id) is null and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0<return_amount+0 or (select sum(payment) as ss from ngo.collection where loan=loan.id) is null and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    else{
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    double ttl=dbs.fill_array(q2,12),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q2,12);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q2);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString nam=dbs.fill_array_string(q2,0);
    dbs.pie3d(ui->lbl_rev_loan,nam,val);
    //dbs.bargraph3d(ui->lbl_rev_loan,nam,val);
}

void form_visualization::on_btn_bar_rev_loan_clicked()
{
    dbsclass dbs;
    QString q2,q3;
    if(ui->ctbx_rev_type->currentText()=="All"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage  FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    else if(ui->ctbx_rev_type->currentText()=="Complete"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage  FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0>=return_amount+0 and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0>=return_amount+0 and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }

    else if(ui->ctbx_rev_type->currentText()=="Incomplete"){
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0<return_amount+0 or (select sum(payment) as ss from ngo.collection where loan=loan.id) is null and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where (select sum(payment) as ss from ngo.collection where loan=loan.id)+0<return_amount+0 or (select sum(payment) as ss from ngo.collection where loan=loan.id) is null and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    else{
        q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
        q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')";
    }
    double ttl=dbs.fill_array(q2,12),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q2,12);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q2);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString nam=dbs.fill_array_string(q2,0);
    //dbs.pie3d(ui->lbl_rev_loan,nam,val);
    dbs.bargraph3d(ui->lbl_rev_loan,nam,val);
}

void form_visualization::on_btn_pie_rev_member_clicked()
{
    dbsclass dbs;
    QString q2="SELECT member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT joining_date FROM ngo.member where id=loan.member) as Joining_date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT joining_date FROM ngo.member where id=loan.member), '%d.%m.%Y'), '%Y-%m-%d')) as Working_Duration,count(id) as Loan_Count,sum(installment) as Total_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Completed_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0) as Ondate_Installment,((((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0)+0)*100)/((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))))+0) as Percentage,sum(amount) as Amount,sum(return_amount) as Return_Amount,(SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Collected_amount,(sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) as Due_Amount,((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0)) as Collected_Capital,(((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)-(((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0))+0)) as Collected_Benefit FROM ngo.loan group by member order by (sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) desc LIMIT "+ui->ctnx_rev_member_limit->currentText()+"";

    dbs.tv_display(ui->tv_rev_member,q2);
    ui->tv_rev_member->resizeColumnsToContents();
    ui->lbl_emp_name->setText(QString::number(q2.length()));

    dbs.generate_singel_graph(ui->plot_rev_member,q2,0,7,"Member Id","On date Collection(%)","Percentage");
    double ttl=dbs.fill_array(q2,12),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q2,12);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q2);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString nam=dbs.fill_array_string(q2,1);
    dbs.pie3d(ui->lbl_rev_member,nam,val);
}

void form_visualization::on_btn_bar_rev_member_clicked()
{
    dbsclass dbs;
    QString q2="SELECT member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT joining_date FROM ngo.member where id=loan.member) as Joining_date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT joining_date FROM ngo.member where id=loan.member), '%d.%m.%Y'), '%Y-%m-%d')) as Working_Duration,count(id) as Loan_Count,sum(installment) as Total_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Completed_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0) as Ondate_Installment,((((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0)+0)*100)/((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))))+0) as Percentage,sum(amount) as Amount,sum(return_amount) as Return_Amount,(SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Collected_amount,(sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) as Due_Amount,((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0)) as Collected_Capital,(((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)-(((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0))+0)) as Collected_Benefit FROM ngo.loan group by member order by (sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) desc LIMIT "+ui->ctnx_rev_member_limit->currentText()+"";

    dbs.tv_display(ui->tv_rev_member,q2);
    ui->tv_rev_member->resizeColumnsToContents();
    ui->lbl_emp_name->setText(QString::number(q2.length()));

    dbs.generate_singel_graph(ui->plot_rev_member,q2,0,7,"Member Id","On date Collection(%)","Percentage");
    double ttl=dbs.fill_array(q2,12),f;
    QString val="",t;
    QString val1=dbs.fill_array_string(q2,12);
    QStringList v=val1.split(",");
    for(int i=0;i<dbs.tbl_sz(q2);i++){
        t=v.value(i);
        f=(t.toDouble()*100)/ttl;

        if(i==0){
            val+=QString::number(f,'g',12);
        }
        else{
            val+=",";
            val+=QString::number(f,'g',12);
        }
    }
    QString nam=dbs.fill_array_string(q2,1);
    //dbs.pie3d(ui->lbl_rev_member,nam,val);
    dbs.bargraph3d(ui->lbl_rev_member,nam,val);
}

void form_visualization::on_ctnx_rev_member_limit_editTextChanged(const QString &arg1)
{

    if(arg1!=""){
        dbsclass dbs;
        QString q="SELECT member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT joining_date FROM ngo.member where id=loan.member) as Joining_date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT joining_date FROM ngo.member where id=loan.member), '%d.%m.%Y'), '%Y-%m-%d')) as Working_Duration,count(id) as Loan_Count,sum(installment) as Total_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Completed_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0) as Ondate_Installment,((((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0)+0)*100)/((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))))+0) as Percentage,sum(amount) as Amount,sum(return_amount) as Return_Amount,(SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Collected_amount,(sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) as Due_Amount,((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0)) as Collected_Capital,(((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)-(((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0))+0)) as Collected_Benefit FROM ngo.loan group by member order by (sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) desc";
        int sz=dbs.tbl_sz(q);
        if(arg1.toDouble()>sz){
            ui->ctnx_rev_member_limit->setEditText(QString::number(sz,'g',12));
        }

        else{
            QString q2="SELECT member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,(SELECT joining_date FROM ngo.member where id=loan.member) as Joining_date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT joining_date FROM ngo.member where id=loan.member), '%d.%m.%Y'), '%Y-%m-%d')) as Working_Duration,count(id) as Loan_Count,sum(installment) as Total_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Completed_Installment,(SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0) as Ondate_Installment,((((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)) and ((DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE((SELECT opening_date FROM ngo.loan where id=collection.loan), '%d/%m/%Y'), '%Y-%m-%d')))+0)%((SELECT gap FROM ngo.loan where id=collection.loan)+0)=0)+0)*100)/((SELECT count(id) FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))))+0) as Percentage,sum(amount) as Amount,sum(return_amount) as Return_Amount,(SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id))) as Collected_amount,(sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) as Due_Amount,((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0)) as Collected_Capital,(((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)-(((((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0)*(sum(amount)+0))/(sum(return_amount)+0))+0)) as Collected_Benefit FROM ngo.loan group by member order by (sum(return_amount)+0)-((SELECT sum(payment)+0 FROM ngo.collection where loan In((SELECT id FROM ngo.loan where member=Member_id)))+0) desc LIMIT "+arg1+"";

            dbs.tv_display(ui->tv_rev_member,q2);
            ui->tv_rev_member->resizeColumnsToContents();
            ui->lbl_emp_name->setText(QString::number(q2.length()));

            dbs.generate_singel_graph(ui->plot_rev_member,q2,0,7,"Member Id","On date Collection(%)","Percentage");
            double ttl=dbs.fill_array(q2,12),f;
            QString val="",t;
            QString val1=dbs.fill_array_string(q2,12);
            QStringList v=val1.split(",");
            for(int i=0;i<dbs.tbl_sz(q2);i++){
                t=v.value(i);
                f=(t.toDouble()*100)/ttl;

                if(i==0){
                    val+=QString::number(f,'g',12);
                }
                else{
                    val+=",";
                    val+=QString::number(f,'g',12);
                }
            }
            QString nam=dbs.fill_array_string(q2,1);
            dbs.pie3d(ui->lbl_rev_member,nam,val);

            ui->tbx_ret_amo__rev_mem->setText(QString::number(dbs.fill_array(q2,10),'g',12));
            ui->tbx_col_amo_rev_mem->setText(QString::number(dbs.fill_array(q2,11),'g',12));
            ui->tbx_due_amo_rev_mem->setText(QString::number(dbs.fill_array(q2,10),'g',12));

            ui->rnd_rev_member->setValue((100/(ui->tbx_ret_amo__rev_mem->text().toDouble()/ui->tbx_col_amo_rev_mem->text().toDouble())));
        }
    }
}

void form_visualization::on_ctbx_rev_loan_editTextChanged(const QString &arg1)
{
    if(arg1!=""){
        dbsclass dbs;
        QString q="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by ((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) desc";
        int sz=dbs.tbl_sz(q);
        if(arg1.toDouble()>sz){
            ui->ctbx_rev_loan->setEditText(QString::number(sz,'g',12));
        }

        else{
            QString q2="SELECT id as Loan_Id,member as Member_id,id as Percentage,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0))+0)/100) as Collected_Benefit,((((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*(amount+0))/(return_amount+0)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by ((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) desc LIMIT "+arg1+"";
            QString q3="SELECT id as Loan_Id,member as Member_id,(SELECT Name FROM ngo.member where id=loan.member) as Name,duration,DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d') as Opening_Date,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) as Duration_Completed,amount,interest,return_amount,((return_amount+0)-(amount+0))as Total_Benefit,(select sum(payment) as ss from ngo.collection where loan=loan.id) as Collected_Amount,((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) as Due_amount,(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100) as Collected_Benefit,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)-(((interest+0)*(select sum(payment) as ss from ngo.collection where loan=loan.id)+0)/100)) as Capital,(((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)*100)/return_amount+0 as percentage FROM ngo.loan where date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(opening_date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"')order by ((return_amount+0)-((select sum(payment) as ss from ngo.collection where loan=loan.id)+0)) desc LIMIT "+arg1+"";

            dbs.tv_display(ui->tv_busnessStatus,q2);
            ui->tv_busnessStatus->resizeColumnsToContents();ui->tbx_loan_amount->setText(QString::number(dbs.fill_array(q2,7),'g',12));
            ui->tbx_ret_amo->setText(QString::number(dbs.fill_array(q2,9),'g',12));
            ui->tbx_col_amo->setText(QString::number(dbs.fill_array(q2,11),'g',12));
            ui->tbx_col_capital->setText(QString::number(dbs.fill_array(q2,14),'g',12));
            ui->tbx_totlbene->setText(QString::number(dbs.fill_array(q2,10),'g',12));
            ui->tbx_col_bene->setText(QString::number(dbs.fill_array(q2,13),'g',12));

            ui->tbx_due_amo->setText(QString::number(ui->tbx_ret_amo->text().toDouble()-ui->tbx_col_amo->text().toDouble()));
            ui->tbx_due_capital->setText(QString::number(ui->tbx_loan_amount->text().toDouble()-ui->tbx_col_capital->text().toDouble()));
            ui->tbx_due_bene->setText(QString::number(ui->tbx_totlbene->text().toDouble()-ui->tbx_col_bene->text().toDouble()));


            for(int i=0;i<dbs.tbl_sz(q2);i++){
                QProgressBar *prog=new QProgressBar();
                QModelIndex in=ui->tv_busnessStatus->model()->index(i,15,QModelIndex());
                QString val=ui->tv_busnessStatus->model()->data(in).toString();
                QModelIndex in2=ui->tv_busnessStatus->model()->index(i,2,QModelIndex());
                prog->setValue(val.toDouble());
                prog->setTextVisible(true);
                ui->tv_busnessStatus->setIndexWidget(in2,prog);
            }
            dbs.generate_singel_graph(ui->plot_rev,q3,0,14,"Loan_Id","Completed(%)","Percentage");
            double ttl=dbs.fill_array(q2,12),f;
            QString val="",t;
            QString val1=dbs.fill_array_string(q2,12);
            QStringList v=val1.split(",");
            for(int i=0;i<dbs.tbl_sz(q2);i++){
                t=v.value(i);
                f=(t.toDouble()*100)/ttl;

                if(i==0){
                    val+=QString::number(f,'g',12);
                }
                else{
                    val+=",";
                    val+=QString::number(f,'g',12);
                }
            }
            QString nam=dbs.fill_array_string(q2,0);
            dbs.pie3d(ui->lbl_rev_loan,nam,val);
        }
    }
}

void form_visualization::on_ctbx_loan_details_coll_type_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
    //dbs.tv_display(ui->tv_ext_missdate,q);
    //ui->tv_ext_datewise->resizeColumnsToContents();

    if(arg1=="On Date Collection"){
        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
        dbs.tv_display(ui->tv_loan_details_coll_type,q);
        ui->tv_loan_details_coll_type->resizeColumnsToContents();
    }
    else if(arg1=="Miss Date Collection"){
        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
        dbs.tv_display(ui->tv_loan_details_coll_type,q);
        ui->tv_loan_details_coll_type->resizeColumnsToContents();
    }
    else if(arg1=="Empty Collection"){
        q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and loan='"+ui->ctnx_loan->currentText()+"' and payment is null order by loan";
        dbs.tv_display(ui->tv_loan_details_coll_type,q);
        ui->tv_loan_details_coll_type->resizeColumnsToContents();
    }
}



void form_visualization::on_btn_pie_loan_details_clicked()
{
    dbsclass dbs;


    QString q;

    q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
    int on_date=dbs.tbl_sz(q);

    q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
    int miss_date=dbs.tbl_sz(q);

    q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and loan='"+ui->ctnx_loan->currentText()+"' and payment is null order by loan";
    int emp_date=dbs.tbl_sz(q);

    double tl=on_date+miss_date+emp_date;

    double f=(on_date*100)/tl;
    QString val=QString::number(f,'g',12);

    f=(miss_date*100)/tl;
    val+=","+QString::number(f,'g',12);

    f=(emp_date*100)/tl;
    val+=","+QString::number(f,'g',12);

    val+=",0";

    QString name="On Date Collection,Miss Date Collection,Empty Collection,o";
    dbs.pie3d(ui->lbl_loan_details,name,val);

}

void form_visualization::on_btn_bar_loan_details_clicked()
{
    dbsclass dbs;


    QString q;

    q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
    int on_date=dbs.tbl_sz(q);

    q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and loan='"+ui->ctnx_loan->currentText()+"' order by loan";
    int miss_date=dbs.tbl_sz(q);

    q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and loan='"+ui->ctnx_loan->currentText()+"' and payment is null order by loan";
    int emp_date=dbs.tbl_sz(q);

    double tl=on_date+miss_date+emp_date;

    double f=(on_date*100)/tl;
    QString val=QString::number(f,'g',12);

    f=(miss_date*100)/tl;
    val+=","+QString::number(f,'g',12);

    f=(emp_date*100)/tl;
    val+=","+QString::number(f,'g',12);

    val+=",0";

    QString name="On Date Collection,Miss Date Collection,Empty Collection,o";
    dbs.bargraph3d(ui->lbl_loan_details,name,val);
}

void form_visualization::on_btn_pie_ext_clicked()
{
    dbsclass dbs;
    //---------------------------------------------------------
    //on date,miss date,empty pie
    QString qq;
    //"On Date Collection"
    qq="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
    int ondate=dbs.tbl_sz(qq);

    //"Miss Date Collection"/
    qq="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
    int missdate=dbs.tbl_sz(qq);

    //"Empty Collection"
    qq="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null order by loan";
    int empty=dbs.tbl_sz(qq);
    double tl=ondate+missdate+empty;

    double f=(ondate*100)/tl;
    QString val=QString::number(f,'g',12);

    f=(missdate*100)/tl;
    val+=","+QString::number(f,'g',12);

    f=(empty*100)/tl;
    val+=","+QString::number(f,'g',12);

    val+=",0";

    QString name="On Date Collection,Miss Date Collection,Empty Collection,o";
    dbs.pie3d(ui->lbl_pie_ext,name,val);
}

void form_visualization::on_btn_bar_ext_clicked()
{
    dbsclass dbs;
    //---------------------------------------------------------
    //on date,miss date,empty pie
    QString qq;
    //"On Date Collection"
    qq="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
    int ondate=dbs.tbl_sz(qq);

    //"Miss Date Collection"/
    qq="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') order by loan";
    int missdate=dbs.tbl_sz(qq);

    //"Empty Collection"
    qq="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and payment is null order by loan";
    int empty=dbs.tbl_sz(qq);
    double tl=ondate+missdate+empty;

    double f=(ondate*100)/tl;
    QString val=QString::number(f,'g',12);

    f=(missdate*100)/tl;
    val+=","+QString::number(f,'g',12);

    f=(empty*100)/tl;
    val+=","+QString::number(f,'g',12);

    val+=",0";

    QString name="On Date Collection,Miss Date Collection,Empty Collection,o";
    dbs.bargraph3d(ui->lbl_pie_ext,name,val);
}

void form_visualization::on_ctbx_member_coll_editTextChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
    //dbs.tv_display(ui->tv_ext_missdate,q);
    //ui->tv_ext_datewise->resizeColumnsToContents();

    if(arg1=="On Date Collection"){
        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0<(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
        dbs.tv_display(ui->tv_member_coll,q);
        ui->tv_member_coll->resizeColumnsToContents();
    }
    else if(arg1=="Miss Date Collection"){
        q="select loan as Loan_Id,installment_date,date,payment,DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>(SELECT gap FROM ngo.loan where id=collection.loan)+0 and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d'))>=date('"+ui->tbx_start_date_inv->text()+"') and date(DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%Y-%m-%d')) <=date('"+ui->tbx_end_date_inv->text()+"') and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' order by loan";
        dbs.tv_display(ui->tv_member_coll,q);
        ui->tv_member_coll->resizeColumnsToContents();
    }
    else if(arg1=="Empty Collection"){
        q="select loan as Loan_Id,installment_date,DATE_FORMAT(now(), '%Y-%m-%d') as Recent_Date,payment,DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')) as Day_Passed,(SELECT gap FROM ngo.loan where id=collection.loan) as Gap from ngo.collection where (DATEDIFF(DATE_FORMAT(now(), '%Y-%m-%d'),DATE_FORMAT(STR_TO_DATE(installment_date, '%d/%m/%Y'), '%Y-%m-%d')))+0>0 and (SELECT member FROM ngo.loan where id=collection.loan)='"+ui->ctbx_member->currentText()+"' and payment is null order by loan";
        dbs.tv_display(ui->tv_member_coll,q);
        ui->tv_member_coll->resizeColumnsToContents();
    }
}

void form_visualization::on_tbx_member_loan_textChanged(const QString &arg1)
{
    dbsclass dbs;
    QString q="SELECT * FROM ngo.member where id='"+arg1+"'";
    ui->tbx_member_name_loan->setText(dbs.fill_string(q,1));
    QByteArray ba=dbs.fill_blob(q,9);

    QPixmap pm;
    pm.loadFromData(ba);
    ui->lbl_img_loan->setPixmap(pm);
    ui->lbl_img_loan->setScaledContents( true );
    ui->lbl_img_loan->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
}
