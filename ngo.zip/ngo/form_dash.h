#ifndef FORM_DASH_H
#define FORM_DASH_H

#include <QWidget>
#include<form_agent.h>
#include<form_loan.h>
#include<login.h>
#include<form_daily_collection.h>
#include<form_visualization.h>
#include<form_daily_payment.h>
#include<form_diposit.h>
#include<form_employee.h>


namespace Ui {
class form_dash;
}

class form_dash : public QWidget
{
    Q_OBJECT
    
public:
    explicit form_dash(QString id);
    ~form_dash();
    
private slots:
    void on_btn_loan_clicked();

    void on_btn_member_clicked();

    void on_btn_collection_clicked();

    void on_btn_cancel_clicked();

    void on_btn_visualization_clicked();

    void on_btn_dash_loan_pie_clicked();

    void on_btn_dash_loan_bar_clicked();

    void on_ctbx_loan_notif_editTextChanged(const QString &arg1);

    void on_btn_deposit_clicked();

    void on_btn_payment_clicked();

    void on_btn_export_clicked();

    void on_btn_import_clicked();

    void on_btn_tranc_clicked();

    void on_btn_upload_clicked();

    void on_btn_backup_clicked();

    void on_btn_restore_clicked();

    void on_btn_employee_clicked();

    void on_ctbx_diposit_editTextChanged(const QString &arg1);

    void on_ctbx_diposit_notification_editTextChanged(const QString &arg1);

private:
    Ui::form_dash *ui;
};

#endif // FORM_DASH_H
